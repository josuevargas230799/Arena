﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 10/11/2026
 * Hora: 10:46 a. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace ArenaElemental
{
	/// <summary>
	/// Description of CartaAgua.
	/// </summary>
	public class CartaAgua : Personaje
	{
		public CartaAgua(DatosCarta d) : base(d)
		{
		}

		//pega un poco mas si el rival tiene escudo
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			if (rival.Escudo > 0)
			{
				danio = (int)Math.Round(danio * 1.1);
			}
			return danio;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			int vidaAntes = Vida;
			Vida = Vida + (int)Math.Round(VidaMax * 0.3);
			int curado = Vida - vidaAntes;
			return Nombre + " usa Marea curativa y recupera " + curado + " de vida";
		}
	}
}
