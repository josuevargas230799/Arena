﻿using System.Collections.Generic;

namespace ArenaElemental
{
	//datos de una carta (se usan en las listas, la BD y para crear el Personaje)
	public class DatosCarta
	{
		public int Id;
		public string Nombre;
		public string Elemento;
		public int HP, DEF, ATK, ENER, EMP;
		public string Descripcion;
		public string DescripcionDetallada;
		public string Imagen; //archivo dentro de la carpeta Recursos
		public string Trasfondo = ""; //pequeña historia del personaje

		public DatosCarta(int id, string nombre, string elemento, int hp, int def, int atk,
		                  int ener, int emp, string desc, string descDetallada)
		{
			Id = id;
			Nombre = nombre;
			Elemento = elemento;
			HP = hp;
			DEF = def;
			ATK = atk;
			ENER = ener;
			EMP = emp;
			Descripcion = desc;
			DescripcionDetallada = descDetallada;
			Imagen = nombre + ".png";
		}

		//los ListBox muestran el nombre
		public override string ToString()
		{
			return Nombre;
		}
	}

	//catalogo de cartas del juego
	public static class Catalogo
	{
		private static List<DatosCarta> lista = null;

		public static List<DatosCarta> Obtener()
		{
			if (lista == null)
			{
				lista = ObtenerLocal();
			}
			return lista;
		}

		//buscar una carta por su nombre
		public static DatosCarta BuscarPorNombre(string nombre)
		{
			foreach (DatosCarta c in Obtener())
			{
				if (c.Nombre == nombre) return c;
			}
			return null;
		}

		//las 12 cartas (HP + DEF + ATK = 100)
		public static List<DatosCarta> ObtenerLocal()
		{
			List<DatosCarta> l = new List<DatosCarta>();
			l.Add(new DatosCarta(1, "Ignis", "Fuego", 40, 20, 40, 5, 3, "Guerrero de llamas.", "Ignis ataca con fuerza bruta. Su habilidad especial lanza una llamarada doble."));
			l.Add(new DatosCarta(2, "Cenia", "Fuego", 50, 25, 25, 6, 5, "Maga de cenizas.", "Cenia equilibra ataque y vida. Su llamarada doble es peligrosa si el rival no tiene escudo."));
			l.Add(new DatosCarta(3, "Brasa", "Fuego", 35, 15, 50, 4, 2, "Atacante veloz.", "Brasa tiene el ataque más alto del elemento, pero cae con facilidad."));
			l.Add(new DatosCarta(4, "Marea", "Agua", 50, 30, 20, 6, 6, "Sanadora del océano.", "Marea resiste mucho y se cura con su habilidad especial."));
			l.Add(new DatosCarta(5, "Torrente", "Agua", 40, 20, 40, 5, 4, "Golpe de corriente.", "Torrente ataca con olas que golpean más fuerte a quien tiene escudo."));
			l.Add(new DatosCarta(6, "Bruma", "Agua", 45, 35, 20, 7, 7, "Defensora serena.", "Bruma tiene mucha empatía: el terremoto la cura en vez de dañarla."));
			l.Add(new DatosCarta(7, "Golem", "Tierra", 55, 35, 10, 4, 2, "Gigante de roca.", "Golem es el personaje más resistente, aunque ataca poco. Su golpe perforante ignora el escudo."));
			l.Add(new DatosCarta(8, "Raiz", "Tierra", 45, 25, 30, 6, 6, "Guardián del bosque.", "Raiz suma daño según su escudo y recibe menos daño del terremoto."));
			l.Add(new DatosCarta(9, "Dolmen", "Tierra", 40, 30, 30, 5, 4, "Piedra antigua.", "Dolmen equilibra defensa y ataque, y es resistente a los terremotos."));
			l.Add(new DatosCarta(10, "Brisa", "Viento", 40, 15, 45, 5, 3, "Cazadora del cielo.", "Brisa golpea fuerte a los rivales con la vida completa."));
			l.Add(new DatosCarta(11, "Ciclon", "Viento", 45, 20, 35, 6, 5, "Torbellino vivo.", "Ciclón roba energía al rival con su habilidad especial."));
			l.Add(new DatosCarta(12, "Aura", "Viento", 50, 30, 20, 7, 8, "Espíritu libre.", "Aura tiene la empatía más alta, aprovecha al máximo el terremoto."));
			PonerTrasfondos(l);
			return l;
		}

		//pequeño trasfondo de cada personaje (en el mismo orden que las cartas de arriba)
		private static void PonerTrasfondos(List<DatosCarta> l)
		{
			string[] t = new string[]
			{
				"Nació junto al volcán que despertó con el primer temblor. Juró que su fuego no se apagaría hasta ganar la Arena.",
				"Fue sacerdotisa de un templo que ardió por completo. De sus cenizas aprendió que todo fuego puede renacer.",
				"La más joven de los campeones de fuego. Nunca espera la orden: cuando ve una chispa, ya está golpeando.",
				"Guardiana de un arrecife que el sismo dejó en ruinas. Pelea para que el mar vuelva a tener hogar.",
				"Corre como el río que se desbordó tras el terremoto. Dicen que ningún escudo resiste una corriente constante.",
				"Vive donde el mar toca la niebla. Escucha el dolor de la tierra, y por eso el temblor la fortalece.",
				"Una montaña que despertó con el primer sismo. No recuerda quién lo talló, solo que debe proteger lo que queda en pie.",
				"Guardián de un bosque antiguo. Sus raíces sienten cada temblor antes de que ocurra y se aferran al suelo.",
				"Piedra levantada por manos olvidadas. Ha visto caer a mil campeones y todavía sigue de pie.",
				"Cazadora de las cumbres. Prefiere el primer golpe, cuando la presa aún no sabe que el cielo la observa.",
				"Un torbellino que despertó en plena tormenta. No odia a nadie: solo tiene hambre de energía.",
				"Espíritu libre que viaja con todos los vientos. Siente tan hondo a los demás que hasta el terremoto le da fuerza."
			};

			for (int i = 0; i < l.Count && i < t.Length; i++)
			{
				l[i].Trasfondo = t[i];
			}
		}
	}

	//crea el personaje correcto segun el elemento (herencia)
	public static class FabricaCartas
	{
		public static Personaje Crear(DatosCarta d)
		{
			if (d.Elemento == "Fuego") return new CartaFuego(d);
			if (d.Elemento == "Agua") return new CartaAgua(d);
			if (d.Elemento == "Tierra") return new CartaTierra(d);
			return new CartaViento(d);
		}
	}
}