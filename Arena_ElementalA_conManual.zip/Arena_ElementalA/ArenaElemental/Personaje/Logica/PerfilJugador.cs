﻿namespace ArenaElemental
{
	//datos de un jugador que inicio sesion
	public class PerfilJugador
	{
		public int Id;          //0 = invitado (no se guarda en la BD)
		public string Nombre;
		public int Partidas;
		public int Victorias;
		public int Derrotas;

		public double PorcentajeExito
		{
			get
			{
				if (Partidas == 0) return 0;
				return Victorias * 100.0 / Partidas;
			}
		}
	}
}
