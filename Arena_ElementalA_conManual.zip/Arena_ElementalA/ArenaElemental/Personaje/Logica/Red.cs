﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ArenaElemental
{
	//conexion TCP entre dos computadoras (se mandan lineas de texto)
	public class Red
	{
		private TcpListener servidor;
		private TcpClient cliente;
		private string pendiente = "";

		//servidor: empezar a escuchar
		public void IniciarServidor(int puerto)
		{
			servidor = new TcpListener(IPAddress.Any, puerto);
			servidor.Start();
		}

		//servidor: revisar si ya llego un cliente
		public bool AceptarSiHay()
		{
			if (servidor == null) return false;
			if (!servidor.Pending()) return false;
			cliente = servidor.AcceptTcpClient();
			return true;
		}

		//cliente: conectarse al servidor (espera 3 segundos como maximo)
		public void Conectar(string ip, int puerto)
		{
			cliente = new TcpClient();
			IAsyncResult resultado = cliente.BeginConnect(ip, puerto, null, null);
			if (!resultado.AsyncWaitHandle.WaitOne(3000))
			{
				cliente.Close();
				throw new Exception("No se pudo conectar (tiempo agotado)");
			}
			cliente.EndConnect(resultado);
		}

		//mandar una linea
		public void Enviar(string linea)
		{
			byte[] datos = Encoding.UTF8.GetBytes(linea + "\n");
			NetworkStream flujo = cliente.GetStream();
			flujo.Write(datos, 0, datos.Length);
		}

		//leer una linea (devuelve null si todavia no llego ninguna)
		public string Leer()
		{
			if (cliente == null) return null;

			NetworkStream flujo = cliente.GetStream();
			while (flujo.DataAvailable)
			{
				byte[] datos = new byte[1024];
				int cantidad = flujo.Read(datos, 0, datos.Length);
				if (cantidad <= 0) break;
				pendiente = pendiente + Encoding.UTF8.GetString(datos, 0, cantidad);
			}

			int posicion = pendiente.IndexOf('\n');
			if (posicion < 0) return null;

			string linea = pendiente.Substring(0, posicion).Trim();
			pendiente = pendiente.Substring(posicion + 1);
			return linea;
		}

		//true si el otro lado cerro la conexion
		public bool Desconectado()
		{
			if (cliente == null) return true;
			try
			{
				return cliente.Client.Poll(0, SelectMode.SelectRead) && cliente.Client.Available == 0;
			}
			catch (Exception)
			{
				return true;
			}
		}

		public void Cerrar()
		{
			try
			{
				if (cliente != null) cliente.Close();
				if (servidor != null) servidor.Stop();
			}
			catch (Exception)
			{
				//no pasa nada si ya estaba cerrado
			}
		}

		//direccion IP de esta computadora
		public static string MiIp()
		{
			try
			{
				IPAddress[] direcciones = Dns.GetHostAddresses(Dns.GetHostName());
				foreach (IPAddress ip in direcciones)
				{
					if (ip.AddressFamily == AddressFamily.InterNetwork) return ip.ToString();
				}
			}
			catch (Exception)
			{
				//si falla se usa la local
			}
			return "127.0.0.1";
		}
	}
}
