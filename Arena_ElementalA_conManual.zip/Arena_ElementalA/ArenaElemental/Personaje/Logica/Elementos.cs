﻿namespace ArenaElemental
{
	//ventajas entre elementos: Agua > Fuego > Viento > Tierra > Agua
	public static class Elementos
	{
		//true si el elemento a vence al elemento b
		public static bool Domina(string a, string b)
		{
			if (a == "Agua" && b == "Fuego") return true;
			if (a == "Fuego" && b == "Viento") return true;
			if (a == "Viento" && b == "Tierra") return true;
			if (a == "Tierra" && b == "Agua") return true;
			return false;
		}

		//multiplicador de dano
		public static double Ventaja(string atacante, string defensor)
		{
			if (Domina(atacante, defensor)) return 1.5;
			if (Domina(defensor, atacante)) return 0.75;
			return 1.0;
		}

		//elemento opuesto (para los escenarios)
		public static string Opuesto(string elemento)
		{
			if (elemento == "Agua") return "Viento";
			if (elemento == "Viento") return "Agua";
			if (elemento == "Fuego") return "Tierra";
			return "Fuego";
		}
	}
}
