﻿using System;

namespace ArenaElemental
{
	//jugador controlado por la computadora (decisiones sencillas)
	public static class Maquina
	{
		private static Random rnd = new Random();

		//devuelve las acciones: [0]=relevar [1]=defender [2]=habilidad [3]=atacar
		public static bool[] Decidir(Partida partida)
		{
			Jugador yo = partida.Actual;
			Personaje p = yo.Activo;
			bool[] acciones = new bool[4];
			int energia = yo.Energia;

			//si esta muy herido a veces se releva
			if (p.Vida * 4 < p.VidaMax && yo.Banca.Count > 0 && energia >= 1 && rnd.Next(100) < 50)
			{
				acciones[0] = true;
			}
			else
			{
				if (p.HabilidadLista && energia >= 2)
				{
					acciones[2] = true;
					energia = energia - 2;
				}
				if (energia >= 1)
				{
					acciones[3] = true;
					energia = energia - 1;
				}
				if (energia >= 1 && rnd.Next(100) < 40)
				{
					acciones[1] = true;
				}
			}
			return acciones;
		}
	}
}
