﻿using System;
using System.Collections.Generic;

namespace ArenaElemental
{
	//motor del combate (aqui vive toda la logica, los forms solo muestran)
	public class Partida
	{
		private Jugador j1;
		private Jugador j2;
		private Jugador actual;
		private Jugador ganador;
		private int turno = 1;
		private int terremotos = 0;
		private bool terminada = false;
		private bool alterno;
		private int indiceEscenario = 0;
		private Random rnd;
		private Escenario[] escenarios = new Escenario[2];

		//pilas y lista de registro
		private Stack<string> historial = new Stack<string>();
		private Stack<string> eventosSismicos = new Stack<string>();
		private List<string> bitacora = new List<string>();

		//lo que paso en el ultimo turno (para mostrarlo en pantalla)
		private List<string> resumen = new List<string>();
		private string ultimoJugador = "";

		public Partida(Jugador a, Jugador b, int semilla, int quienInicia, bool escenarioAlterno)
		{
			j1 = a;
			j2 = b;
			alterno = escenarioAlterno;

			//el mismo numero de semilla da los mismos resultados en las dos computadoras
			rnd = new Random(semilla);

			//escenarios
			int e1 = rnd.Next(4);
			int e2 = (e1 + 1 + rnd.Next(3)) % 4;
			escenarios[0] = FabricaEscenarios.Crear(e1);
			escenarios[1] = FabricaEscenarios.Crear(e2);

			//quien empieza (empieza con 2 de energia)
			if (quienInicia == 1)
			{
				actual = j1;
			}
			else
			{
				actual = j2;
			}
			actual.AgregarEnergia(2);

			RegistrarSoloBitacora("Comienza la batalla: " + j1.Nombre + " vs " + j2.Nombre);
			IniciarTurno();
		}

		//propiedades
		public Jugador Jugador1 { get { return j1; } }
		public Jugador Jugador2 { get { return j2; } }
		public Jugador Actual { get { return actual; } }
		public Jugador Ganador { get { return ganador; } }
		public bool Terminada { get { return terminada; } }
		public int Turno { get { return turno; } }
		public int Terremotos { get { return terremotos; } }
		public Stack<string> Historial { get { return historial; } }
		public Stack<string> EventosSismicos { get { return eventosSismicos; } }
		public List<string> Bitacora { get { return bitacora; } }
		public List<string> UltimoResumen { get { return resumen; } }
		public string UltimoJugador { get { return ultimoJugador; } }

		public Escenario EscenarioActual
		{
			get { return escenarios[indiceEscenario]; }
		}

		//el rival de un jugador
		public Jugador Rival(Jugador j)
		{
			if (j == j1) return j2;
			return j1;
		}

		//guardar un texto en la bitacora, en la pila y en el resumen del turno
		private void Registrar(string texto)
		{
			RegistrarSoloBitacora(texto);
			resumen.Add(texto);
		}

		//guardar solo en la bitacora y en la pila
		private void RegistrarSoloBitacora(string texto)
		{
			string linea = "[T" + turno + "] " + texto;
			bitacora.Add(linea);
			historial.Push(linea);
		}

		//inicio de un turno
		private void IniciarTurno()
		{
			if (alterno && turno > 1)
			{
				indiceEscenario = 1 - indiceEscenario;
			}

			//gana 1 de energia por turno (el primer turno ya tiene 2)
			if (turno > 1)
			{
				actual.AgregarEnergia(1);
			}

			//la habilidad se carga 50 por turno (2 turnos para cargarse)
			actual.Activo.Carga = actual.Activo.Carga + 50;

			RegistrarSoloBitacora("Turno de " + actual.Nombre + " | Energía: " + actual.Energia + " | Escenario: " + EscenarioActual.Nombre);
		}

		//ejecutar todas las acciones elegidas y pasar al siguiente turno
		public void EjecutarTurno(bool relevar, bool defender, bool habilidad, bool atacar)
		{
			if (terminada) return;

			//empieza un resumen nuevo para este turno
			resumen.Clear();
			ultimoJugador = actual.Nombre;

			Jugador yo = actual;
			Jugador rival = Rival(yo);

			if (!relevar && !defender && !habilidad && !atacar)
			{
				Registrar(yo.Nombre + " pasa el turno y ahorra energía.");
			}

			if (relevar && !terminada) AccionRelevar(yo);
			if (defender && !terminada) AccionDefender(yo);
			if (habilidad && !terminada) AccionHabilidad(yo, rival);
			if (atacar && !terminada) AccionAtacar(yo, rival);

			TerminarTurno();
		}

		//ATACAR (cuesta 1)
		private void AccionAtacar(Jugador yo, Jugador rival)
		{
			if (!yo.GastarEnergia(1))
			{
				Registrar(yo.Nombre + " no tiene energía para atacar.");
				return;
			}

			Personaje atacante = yo.Activo;
			Personaje objetivo = rival.Activo;
			int danio = atacante.CalcularDanio(objetivo, EscenarioActual);
			int escudoAntes = objetivo.Escudo;
			int vidaPerdida = objetivo.RecibirDanio(danio);
			int absorbido = Math.Min(escudoAntes, danio);

			//texto facil de entender
			string texto = atacante.Nombre + " ataca a " + objetivo.Nombre + " y le hace " + danio + " de daño.";
			if (absorbido > 0)
			{
				texto = texto + " El escudo absorbe " + absorbido + ".";
			}
			texto = texto + " Pierde " + vidaPerdida + " de vida.";

			double ventaja = Elementos.Ventaja(atacante.Elemento, objetivo.Elemento);
			if (ventaja > 1) texto = texto + " ¡Ataque muy efectivo!";
			if (ventaja < 1) texto = texto + " Ataque poco efectivo.";

			Registrar(texto);
			ComprobarMuerte(rival);
		}

		//DEFENDER (cuesta 1)
		private void AccionDefender(Jugador yo)
		{
			if (!yo.GastarEnergia(1))
			{
				Registrar(yo.Nombre + " no tiene energía para defender.");
				return;
			}

			Personaje p = yo.Activo;
			int escudoAntes = p.Escudo;
			p.Escudo = p.Escudo + (int)Math.Round(3.0 * Math.Sqrt(p.DefensaBase));
			Registrar(p.Nombre + " se defiende: su escudo sube de " + escudoAntes + " a " + p.Escudo + ".");
		}

		//HABILIDAD ESPECIAL (cuesta 2 y necesita carga al 100%)
		private void AccionHabilidad(Jugador yo, Jugador rival)
		{
			Personaje p = yo.Activo;

			if (!p.HabilidadLista)
			{
				Registrar(p.Nombre + " todavía no tiene la habilidad cargada.");
				return;
			}
			if (!yo.GastarEnergia(2))
			{
				Registrar(yo.Nombre + " no tiene energía para la habilidad.");
				return;
			}

			p.Carga = 0;
			Registrar("¡Habilidad especial! " + p.HabilidadEspecial(yo, rival, EscenarioActual) + ".");
			ComprobarMuerte(rival);
		}

		//RELEVAR (cuesta 1)
		private void AccionRelevar(Jugador yo)
		{
			if (yo.Banca.Count == 0)
			{
				Registrar(yo.Nombre + " no tiene personajes para relevar.");
				return;
			}
			if (!yo.GastarEnergia(1))
			{
				Registrar(yo.Nombre + " no tiene energía para relevar.");
				return;
			}

			string saliente = yo.Activo.Nombre;
			yo.Relevar();
			Registrar(yo.Nombre + " releva a " + saliente + ": entra " + yo.Activo.Nombre + ".");
		}

		//si el activo cayo entra el siguiente de la cola
		private void ComprobarMuerte(Jugador j)
		{
			if (j.Activo.EstaVivo) return;

			Registrar("¡" + j.Activo.Nombre + " de " + j.Nombre + " queda fuera de combate!");

			if (j.ReemplazarCaido())
			{
				Registrar("Entra " + j.Activo.Nombre + " por " + j.Nombre + ".");
			}
			else
			{
				terminada = true;
				ganador = Rival(j);
				Registrar("¡Fin de la partida! Gana " + ganador.Nombre + ".");
			}
		}

		//fin del turno
		private void TerminarTurno()
		{
			if (terminada) return;

			//el terremoto se revisa al final de cada ronda
			if (turno % 2 == 0)
			{
				ComprobarTerremoto();
			}

			turno++;
			actual = Rival(actual);
			IniciarTurno();
		}

		//terremoto: cada 6 turnos seguro, y 15% de probabilidad en las demas rondas
		private void ComprobarTerremoto()
		{
			bool ocurre = (turno % 6 == 0) || (rnd.Next(100) < 15);
			if (!ocurre) return;

			terremotos++;
			Registrar("¡TERREMOTO en " + EscenarioActual.Nombre + "!");
			eventosSismicos.Push("Terremoto " + terremotos + " (turno " + turno + ")");

			AplicarTerremoto(j1);
			AplicarTerremoto(j2);
		}

		private void AplicarTerremoto(Jugador j)
		{
			Personaje p = j.Activo;
			int sismo = (int)Math.Round(p.VidaMax * EscenarioActual.FactorTerremoto());

			//la facción Tierra resiste la mitad
			if (p.Elemento == "Tierra")
			{
				sismo = sismo / 2;
			}

			if (p.Empatia >= Configuracion.UMBRAL_EMPATIA)
			{
				//empatia alta: el terremoto se invierte
				int vidaAntes = p.Vida;
				p.Vida = p.Vida + sismo;
				p.Escudo = p.Escudo + sismo / 2;
				Registrar(p.Nombre + " (empatía " + p.Empatia + ") aprovecha el terremoto: +" + (p.Vida - vidaAntes) + " de vida y +" + (sismo / 2) + " de escudo.");
			}
			else
			{
				//el escudo se reduce a la mitad y se pierde vida (sin llegar a 0)
				p.Escudo = p.Escudo / 2;
				int danio = sismo;
				if (danio > p.Vida - 1) danio = p.Vida - 1;
				if (danio < 0) danio = 0;
				p.Vida = p.Vida - danio;
				Registrar(p.Nombre + " sufre el terremoto: -" + danio + " de vida y su escudo baja a " + p.Escudo + ".");
			}
		}

		//cuando un jugador abandona o se pierde la conexion
		public void TerminarPorAbandono(Jugador queGana)
		{
			if (terminada) return;
			terminada = true;
			ganador = queGana;
			Registrar("El rival abandonó. Gana " + ganador.Nombre + ".");
		}
	}
}
