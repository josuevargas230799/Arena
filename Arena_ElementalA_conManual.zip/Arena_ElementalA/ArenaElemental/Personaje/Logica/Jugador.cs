﻿using System;
using System.Collections.Generic;

namespace ArenaElemental
{
	public class Jugador
	{
		private string nombre;
		private int numero;
		private int energia;
		private Personaje activo;
		private Queue<Personaje> banca = new Queue<Personaje>(); //cola de relevos
		private List<string> nombresEquipo = new List<string>();

		public Jugador(string nombre, int numero, List<DatosCarta> equipo)
		{
			this.nombre = nombre;
			this.numero = numero;

			//la primera carta es la activa, las demas van a la cola
			for (int i = 0; i < equipo.Count; i++)
			{
				Personaje p = FabricaCartas.Crear(equipo[i]);
				nombresEquipo.Add(p.Nombre);
				if (i == 0)
				{
					activo = p;
				}
				else
				{
					banca.Enqueue(p);
				}
			}
		}

		public string Nombre
		{
			get { return nombre; }
		}

		public int Numero
		{
			get { return numero; }
		}

		public int Energia
		{
			get { return energia; }
		}

		public Personaje Activo
		{
			get { return activo; }
		}

		public Queue<Personaje> Banca
		{
			get { return banca; }
		}

		public List<string> NombresEquipo
		{
			get { return nombresEquipo; }
		}

		//personajes que le quedan (activo + banca)
		public int PersonajesRestantes
		{
			get
			{
				int total = banca.Count;
				if (activo.EstaVivo) total++;
				return total;
			}
		}

		//energia
		public void AgregarEnergia(int cantidad)
		{
			energia = energia + cantidad;
			if (energia > activo.EnergiaMax) energia = activo.EnergiaMax;
		}

		public bool GastarEnergia(int cantidad)
		{
			if (energia < cantidad) return false;
			energia = energia - cantidad;
			return true;
		}

		//devuelve cuanta energia se le quito
		public int QuitarEnergia(int cantidad)
		{
			int quitada = Math.Min(cantidad, energia);
			energia = energia - quitada;
			return quitada;
		}

		//relevo voluntario: el activo pasa al final de la cola
		public bool Relevar()
		{
			if (banca.Count == 0) return false;
			Personaje saliente = activo;
			activo = banca.Dequeue();
			banca.Enqueue(saliente);
			return true;
		}

		//relevo forzado: el activo cayo y no vuelve a la cola
		public bool ReemplazarCaido()
		{
			if (banca.Count == 0) return false;
			activo = banca.Dequeue();
			return true;
		}
	}
}
