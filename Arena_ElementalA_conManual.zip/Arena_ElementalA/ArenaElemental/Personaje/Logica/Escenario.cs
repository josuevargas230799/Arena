﻿using System.Collections.Generic;

namespace ArenaElemental
{
	//clase base de los escenarios
	public abstract class Escenario
	{
		private string nombre;
		private string elemento;

		public Escenario(string nombre, string elemento)
		{
			this.nombre = nombre;
			this.elemento = elemento;
		}

		public string Nombre
		{
			get { return nombre; }
		}

		public string Elemento
		{
			get { return elemento; }
		}

		//archivo de imagen de fondo del escenario (carpeta Recursos)
		public string Fondo
		{
			get { return "fondo_" + elemento.ToLower() + ".png"; }
		}

		//mejora o penalizacion de dano segun el elemento del personaje
		public double Bono(string elementoPersonaje)
		{
			if (elementoPersonaje == elemento) return 1.2;
			if (elementoPersonaje == Elementos.Opuesto(elemento)) return 0.8;
			return 1.0;
		}

		//porcentaje de vida maxima que quita el terremoto
		public abstract double FactorTerremoto();
	}

	public class EscenarioVolcan : Escenario
	{
		public EscenarioVolcan() : base("Volcán Activo", "Fuego")
		{
		}

		public override double FactorTerremoto()
		{
			return 0.15;
		}
	}

	public class EscenarioAbismo : Escenario
	{
		public EscenarioAbismo() : base("Abismo Oceánico", "Agua")
		{
		}

		public override double FactorTerremoto()
		{
			return 0.10;
		}
	}

	public class EscenarioCanon : Escenario
	{
		public EscenarioCanon() : base("Cañón Rocoso", "Tierra")
		{
		}

		public override double FactorTerremoto()
		{
			return 0.20;
		}
	}

	public class EscenarioCumbre : Escenario
	{
		public EscenarioCumbre() : base("Cumbre de Viento", "Viento")
		{
		}

		public override double FactorTerremoto()
		{
			return 0.12;
		}
	}

	//crea los escenarios
	public static class FabricaEscenarios
	{
		public static Escenario Crear(int indice)
		{
			if (indice == 0) return new EscenarioVolcan();
			if (indice == 1) return new EscenarioAbismo();
			if (indice == 2) return new EscenarioCanon();
			return new EscenarioCumbre();
		}

		public static List<Escenario> Todos()
		{
			List<Escenario> lista = new List<Escenario>();
			for (int i = 0; i < 4; i++)
			{
				lista.Add(Crear(i));
			}
			return lista;
		}
	}
}
