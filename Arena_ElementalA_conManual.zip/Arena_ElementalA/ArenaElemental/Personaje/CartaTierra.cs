﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 10/11/2026
 * Hora: 10:47 a. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace ArenaElemental
{
	/// <summary>
	/// Description of CartaTierra.
	/// </summary>
	public class CartaTierra : Personaje
	{
		public CartaTierra(DatosCarta d) : base(d)
		{
		}

		//suma un poco de dano segun su propio escudo
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			return danio + Escudo / 10;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			Personaje objetivo = rival.Activo;
			int danio = (int)Math.Round(CalcularDanio(objetivo, esc) * 1.3);
			int perdido = objetivo.RecibirDanioDirecto(danio);
			return Nombre + " usa Golpe perforante (ignora el escudo) y quita " + perdido + " de vida a " + objetivo.Nombre;
		}
	}
}
