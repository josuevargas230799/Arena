﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 10/11/2026
 * Hora: 10:44 a. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace ArenaElemental
{
	/// <summary>
	/// Description of CartaFuego.
	/// </summary>
	public class CartaFuego : Personaje
	{
		public CartaFuego(DatosCarta d) : base(d)
		{
		}

		//pega mas fuerte si el rival no tiene escudo
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			if (rival.Escudo == 0)
			{
				danio = (int)Math.Round(danio * 1.2);
			}
			return danio;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			Personaje objetivo = rival.Activo;
			int total = 0;
			for (int i = 0; i < 2; i++)
			{
				int danio = CalcularDanio(objetivo, esc);
				total = total + objetivo.RecibirDanio(danio);
			}
			return Nombre + " usa Llamarada doble y quita " + total + " de vida a " + objetivo.Nombre;
		}
	}
}
