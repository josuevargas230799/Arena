﻿using System;

namespace ArenaElemental
{
	//clase base de todas las cartas de personaje
	public abstract class Personaje
	{
		//atributos privados (encapsulamiento)
		private string nombre;
		private string elemento;
		private int vidaMax;
		private int vida;
		private int escudoMax;
		private int escudo;
		private int defensaBase;
		private int ataque;
		private int empatia;
		private int energiaMax;
		private int carga;

		public Personaje(DatosCarta d)
		{
			nombre = d.Nombre;
			elemento = d.Elemento;
			vidaMax = d.HP;
			vida = d.HP;
			defensaBase = d.DEF;
			escudoMax = d.DEF * 2;
			escudo = d.DEF;
			ataque = d.ATK;
			empatia = d.EMP;
			energiaMax = d.ENER;
			carga = 0;
		}

		//propiedades
		public string Nombre
		{
			get { return nombre; }
		}

		public string Elemento
		{
			get { return elemento; }
		}

		public int VidaMax
		{
			get { return vidaMax; }
		}

		public int Vida
		{
			get { return vida; }
			set
			{
				//la vida no baja de 0 ni pasa del maximo
				if (value < 0) value = 0;
				if (value > vidaMax) value = vidaMax;
				vida = value;
			}
		}

		public int EscudoMax
		{
			get { return escudoMax; }
		}

		public int Escudo
		{
			get { return escudo; }
			set
			{
				if (value < 0) value = 0;
				if (value > escudoMax) value = escudoMax;
				escudo = value;
			}
		}

		public int DefensaBase
		{
			get { return defensaBase; }
		}

		public int Ataque
		{
			get { return ataque; }
		}

		public int Empatia
		{
			get { return empatia; }
		}

		public int EnergiaMax
		{
			get { return energiaMax; }
		}

		//carga de la habilidad especial (0 a 100)
		public int Carga
		{
			get { return carga; }
			set
			{
				if (value < 0) value = 0;
				if (value > 100) value = 100;
				carga = value;
			}
		}

		public bool EstaVivo
		{
			get { return vida > 0; }
		}

		public bool HabilidadLista
		{
			get { return carga >= 100; }
		}

		//dano normal: primero se gasta el escudo y el resto va a la vida
		//devuelve cuanta vida se perdio
		public int RecibirDanio(int danio)
		{
			if (danio < 0) danio = 0;

			if (danio <= escudo)
			{
				escudo = escudo - danio;
				return 0;
			}

			int sobrante = danio - escudo;
			escudo = 0;
			int vidaAntes = vida;
			Vida = vida - sobrante;
			return vidaAntes - vida;
		}

		//dano que ignora el escudo
		public int RecibirDanioDirecto(int danio)
		{
			if (danio < 0) danio = 0;
			int vidaAntes = vida;
			Vida = vida - danio;
			return vidaAntes - vida;
		}

		//formula de dano (usa una raiz, no es lineal)
		public virtual int CalcularDanio(Personaje rival, Escenario esc)
		{
			double basico = 5.0 * Math.Sqrt(ataque);
			double ventaja = Elementos.Ventaja(elemento, rival.Elemento);
			double bono = esc.Bono(elemento);
			double total = basico * ventaja * bono;
			return (int)Math.Round(total);
		}

		//cada elemento tiene su habilidad
		public abstract string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc);
	}
}
