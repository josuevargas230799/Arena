﻿using System;

namespace ArenaElemental
{
	//FUEGO: impacto doble
	/*public class CartaFuego : Personaje
	{
		public CartaFuego(DatosCarta d) : base(d)
		{
		}

		//pega mas fuerte si el rival no tiene escudo
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			if (rival.Escudo == 0)
			{
				danio = (int)Math.Round(danio * 1.2);
			}
			return danio;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			Personaje objetivo = rival.Activo;
			int total = 0;
			for (int i = 0; i < 2; i++)
			{
				int danio = CalcularDanio(objetivo, esc);
				total = total + objetivo.RecibirDanio(danio);
			}
			return Nombre + " usa Llamarada doble y quita " + total + " de vida a " + objetivo.Nombre;
		}
	}

	//AGUA: curacion
	public class CartaAgua : Personaje
	{
		public CartaAgua(DatosCarta d) : base(d)
		{
		}

		//pega un poco mas si el rival tiene escudo
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			if (rival.Escudo > 0)
			{
				danio = (int)Math.Round(danio * 1.1);
			}
			return danio;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			int vidaAntes = Vida;
			Vida = Vida + (int)Math.Round(VidaMax * 0.3);
			int curado = Vida - vidaAntes;
			return Nombre + " usa Marea curativa y recupera " + curado + " de vida";
		}
	}

	//TIERRA: dano perforante
	public class CartaTierra : Personaje
	{
		public CartaTierra(DatosCarta d) : base(d)
		{
		}

		//suma un poco de dano segun su propio escudo
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			return danio + Escudo / 10;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			Personaje objetivo = rival.Activo;
			int danio = (int)Math.Round(CalcularDanio(objetivo, esc) * 1.3);
			int perdido = objetivo.RecibirDanioDirecto(danio);
			return Nombre + " usa Golpe perforante (ignora el escudo) y quita " + perdido + " de vida a " + objetivo.Nombre;
		}
	}

	//VIENTO: drenaje de energia
	public class CartaViento : Personaje
	{
		public CartaViento(DatosCarta d) : base(d)
		{
		}

		//golpe sorpresa si el rival tiene la vida completa
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			if (rival.Vida == rival.VidaMax)
			{
				danio = (int)Math.Round(danio * 1.1);
			}
			return danio;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			Personaje objetivo = rival.Activo;
			int robada = rival.QuitarEnergia(2);
			dueno.AgregarEnergia(robada);
			int danio = CalcularDanio(objetivo, esc) / 2;
			int perdido = objetivo.RecibirDanio(danio);
			return Nombre + " usa Drenaje: roba " + robada + " de energia y quita " + perdido + " de vida a " + objetivo.Nombre;
		}
	}*/
}
