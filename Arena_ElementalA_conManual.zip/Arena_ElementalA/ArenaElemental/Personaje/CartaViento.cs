﻿/*
 * Creado por SharpDevelop.
 * Usuario: usuario
 * Fecha: 10/11/2026
 * Hora: 10:47 a. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace ArenaElemental
{
	/// <summary>
	/// Description of CartaViento.
	/// </summary>
	public class CartaViento : Personaje
	{
		public CartaViento(DatosCarta d) : base(d)
		{
		}

		//golpe sorpresa si el rival tiene la vida completa
		public override int CalcularDanio(Personaje rival, Escenario esc)
		{
			int danio = base.CalcularDanio(rival, esc);
			if (rival.Vida == rival.VidaMax)
			{
				danio = (int)Math.Round(danio * 1.1);
			}
			return danio;
		}

		public override string HabilidadEspecial(Jugador dueno, Jugador rival, Escenario esc)
		{
			Personaje objetivo = rival.Activo;
			int robada = rival.QuitarEnergia(2);
			dueno.AgregarEnergia(robada);
			int danio = CalcularDanio(objetivo, esc) / 2;
			int perdido = objetivo.RecibirDanio(danio);
			return Nombre + " usa Drenaje: roba " + robada + " de energía y quita " + perdido + " de vida a " + objetivo.Nombre;
		}
	}
}
