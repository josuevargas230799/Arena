﻿using System;
using System.Windows.Forms;

namespace ArenaElemental
{
	internal sealed class Program
	{
		[STAThread]
		private static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			//prologo: cielo estrellado antes del menu
			FormLore prologo = new FormLore();
			prologo.ShowDialog();
			prologo.Dispose();

			//el programa sigue en el menu principal
			Application.Run(new FormMenuPrincipal());
		}
	}
}
