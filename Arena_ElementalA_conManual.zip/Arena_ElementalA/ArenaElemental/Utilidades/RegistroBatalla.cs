﻿using System;
using System.IO;
using System.Windows.Forms;

namespace ArenaElemental
{
	//guarda la bitacora de la batalla en un archivo .txt
	public static class RegistroBatalla
	{
		//devuelve la ruta del archivo ("" si no se pudo guardar)
		public static string Guardar(Partida partida, string modo)
		{
			try
			{
				string carpeta = Path.Combine(Application.StartupPath, "Logs");
				Directory.CreateDirectory(carpeta);

				string nombre = "Batalla_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";
				string ruta = Path.Combine(carpeta, nombre);

				using (StreamWriter sw = new StreamWriter(ruta))
				{
					//encabezado
					sw.WriteLine("ARENA ELEMENTAL - BITACORA DE BATALLA");
					sw.WriteLine("Fecha: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
					sw.WriteLine("Modo: " + modo);
					sw.WriteLine("Jugador 1: " + partida.Jugador1.Nombre + " (" + string.Join(", ", partida.Jugador1.NombresEquipo.ToArray()) + ")");
					sw.WriteLine("Jugador 2: " + partida.Jugador2.Nombre + " (" + string.Join(", ", partida.Jugador2.NombresEquipo.ToArray()) + ")");
					sw.WriteLine("------------------------------------------");

					//acciones turno por turno
					foreach (string linea in partida.Bitacora)
					{
						sw.WriteLine(linea);
					}

					//resumen
					sw.WriteLine("------------------------------------------");
					sw.WriteLine("Turnos jugados: " + partida.Turno);
					sw.WriteLine("Terremotos ocurridos: " + partida.Terremotos);
					if (partida.EventosSismicos.Count > 0)
					{
						sw.WriteLine("Ultimo terremoto: " + partida.EventosSismicos.Peek());
					}
					if (partida.Ganador != null)
					{
						sw.WriteLine("GANADOR: " + partida.Ganador.Nombre);
					}
				}
				return ruta;
			}
			catch (Exception ex)
			{
				MessageBox.Show("No se pudo guardar el archivo de bitacora: " + ex.Message);
				return "";
			}
		}
	}
}
