﻿/*
 * Creado por SharpDevelop.
 * Usuario: arnoldo
 * Fecha: 6 sept. 2026
 * Hora: 8:07 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Windows.Forms;

namespace ArenaElemental
{
	/// <summary>
	/// Description of Manual.
	/// </summary>
	public static class Manual
	{
		const string NombreManual = "Manual_Arena_Elemental_ES-EN.pdf";
		const string UrlDescarga = "https://drive.google.com/uc?export=download&id=19wZTgJMROT82geJppkOfXmxkUUeVifOY";
		const string UrlVista = "https://drive.google.com/file/d/19wZTgJMROT82geJppkOfXmxkUUeVifOY/view";
		
		static string RutaLocal()
		{
			return Path.Combine(Application.StartupPath, Path.Combine("Recursos", NombreManual));
		}
		
		public static void AbrirManual()
		{
			try
			{
				string ruta = RutaLocal();
				string destino = File.Exists(ruta) ? ruta : UrlVista;
				ProcessStartInfo info = new ProcessStartInfo(destino);
				info.UseShellExecute = true;
				Process.Start(info);
			}
			catch (Exception ex)
			{
				MessageBox.Show("No se pudo abrir el manual.\n" + ex.Message,
					"Manual", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}
		
		public static void DescargarManual()
		{
			using (SaveFileDialog dlg = new SaveFileDialog())
			{
				dlg.Title = "Guardar manual";
				dlg.Filter = "Documento PDF (*.pdf)|*.pdf";
				dlg.FileName = NombreManual;
				if (dlg.ShowDialog() != DialogResult.OK) return;
				
				Cursor anterior = Cursor.Current;
				try
				{
					Cursor.Current = Cursors.WaitCursor;
					string local = RutaLocal();
					if (File.Exists(local))
					{
						File.Copy(local, dlg.FileName, true);
					}
					else
					{
						try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; } // TLS 1.2
						catch (Exception) { }
						using (WebClient wc = new WebClient())
						{
							wc.DownloadFile(UrlDescarga, dlg.FileName);
						}
					}
					MessageBox.Show("Manual guardado en:\n" + dlg.FileName,
						"Manual", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show("No se pudo descargar el manual.\n" + ex.Message,
						"Manual", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				finally
				{
					Cursor.Current = anterior;
				}
			}
		}
	}
}
