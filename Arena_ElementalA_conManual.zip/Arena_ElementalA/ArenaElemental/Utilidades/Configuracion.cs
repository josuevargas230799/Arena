﻿namespace ArenaElemental
{
	//valores generales del juego
	public static class Configuracion
	{
		//opciones que se cambian en el form Opciones
		public static int TiempoTurno = 20;
		public static bool EscenarioAlterno = false;

		//reglas
		public const int MAX_EQUIPO = 5;
		public const int UMBRAL_EMPATIA = 7;
	}
}
