﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ArenaElemental
{
	//colores, fuente e imagenes que usan todos los forms
	public static class Estilo
	{
		//colores
		public static readonly Color Fondo = Color.FromArgb(20, 22, 40);
		public static readonly Color Boton = Color.FromArgb(40, 48, 70);
		public static readonly Color BotonHover = Color.FromArgb(62, 74, 108);
		public static readonly Color BotonActivo = Color.FromArgb(150, 90, 40);
		public static readonly Color Texto = Color.White;

		//fuente general
		public static readonly Font Fuente = new Font("Segoe Print", 11f);

		//imagenes ya cargadas
		private static Dictionary<string, Image> cache = new Dictionary<string, Image>();

		//aplicar el estilo a un form
		public static void Aplicar(Form f, string fondo)
		{
			f.BackColor = Fondo;
			f.ForeColor = Texto;
			f.Font = Fuente;

			//fondo de pantalla
			Image img = CargarImagen(fondo);
			if (img != null)
			{
				f.BackgroundImage = img;
				f.BackgroundImageLayout = ImageLayout.Stretch;
			}

			//estilo de los controles
			EstilizarControles(f);
		}

		//recorrer los controles y darles estilo
		private static void EstilizarControles(Control padre)
		{
			foreach (Control c in padre.Controls)
			{
				//botones
				if (c is Button)
				{
					Button b = (Button)c;
					b.FlatStyle = FlatStyle.Flat;
					b.FlatAppearance.BorderSize = 0;
					b.FlatAppearance.MouseOverBackColor = BotonHover;
					b.BackColor = Boton;
					b.ForeColor = Texto;
					b.Cursor = Cursors.Hand;
				}
				//botones de marcar (acciones de la batalla)
				else if (c is CheckBox)
				{
					CheckBox cb = (CheckBox)c;
					cb.FlatStyle = FlatStyle.Flat;
					cb.FlatAppearance.BorderSize = 0;
					cb.FlatAppearance.MouseOverBackColor = BotonHover;
					cb.FlatAppearance.CheckedBackColor = BotonActivo;
					cb.BackColor = Boton;
					cb.ForeColor = Texto;
					cb.Cursor = Cursors.Hand;
				}
				//combos
				else if (c is ComboBox)
				{
					c.BackColor = Fondo;
					c.ForeColor = Texto;
					((ComboBox)c).FlatStyle = FlatStyle.Flat;
				}
				//textos
				else if (c is Label)
				{
					c.BackColor = Color.Transparent;
					c.ForeColor = Texto;
				}
				//listas
				else if (c is ListBox)
				{
					((ListBox)c).BorderStyle = BorderStyle.FixedSingle;
				}

				//controles dentro de paneles
				if (c.HasChildren)
				{
					EstilizarControles(c);
				}
			}
		}

		//cargar una imagen de la carpeta Recursos (null si no existe)
		public static Image CargarImagen(string nombre)
		{
			if (string.IsNullOrEmpty(nombre)) return null;

			if (cache.ContainsKey(nombre)) return cache[nombre];

			string ruta = Path.Combine(Application.StartupPath, Path.Combine("Recursos", nombre));
			if (!File.Exists(ruta)) return null;

			Image img = Image.FromFile(ruta);
			cache[nombre] = img;
			return img;
		}
	}
}
