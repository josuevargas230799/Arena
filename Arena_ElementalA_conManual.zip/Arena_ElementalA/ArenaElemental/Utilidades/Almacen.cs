﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace ArenaElemental
{
	//guarda y lee los datos en archivos de texto (carpeta Datos)
	//
	//jugadores.txt -> id|usuario|clave|partidas|victorias|derrotas
	//equipos.txt   -> idJugador|idCarta1,idCarta2,idCarta3,idCarta4,idCarta5
	//partidas.txt  -> fecha|idJugador|rival|resultado|turnos|archivoLog
	public static class Almacen
	{
		public static string UltimoError = "";

		//rutas de los archivos
		private static string Carpeta()
		{
			return Path.Combine(Application.StartupPath, "Datos");
		}

		private static string RutaJugadores()
		{
			return Path.Combine(Carpeta(), "jugadores.txt");
		}

		private static string RutaEquipos()
		{
			return Path.Combine(Carpeta(), "equipos.txt");
		}

		private static string RutaPartidas()
		{
			return Path.Combine(Carpeta(), "partidas.txt");
		}

		//crear la carpeta y los archivos si no existen
		public static bool Inicializar()
		{
			try
			{
				Directory.CreateDirectory(Carpeta());
				CrearSiNoExiste(RutaJugadores());
				CrearSiNoExiste(RutaEquipos());
				CrearSiNoExiste(RutaPartidas());
				UltimoError = "";
				return true;
			}
			catch (Exception ex)
			{
				UltimoError = ex.Message;
				return false;
			}
		}

		private static void CrearSiNoExiste(string ruta)
		{
			if (!File.Exists(ruta))
			{
				File.WriteAllText(ruta, "");
			}
		}

		//clave guardada como SHA256 (no se guarda el texto)
		private static string Hash(string texto)
		{
			using (SHA256 sha = SHA256.Create())
			{
				byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(texto));
				return BitConverter.ToString(bytes).Replace("-", "");
			}
		}

		//convertir una linea de jugadores.txt en un perfil
		private static PerfilJugador LeerPerfil(string[] campos)
		{
			PerfilJugador p = new PerfilJugador();
			p.Id = int.Parse(campos[0]);
			p.Nombre = campos[1];
			p.Partidas = int.Parse(campos[3]);
			p.Victorias = int.Parse(campos[4]);
			p.Derrotas = int.Parse(campos[5]);
			return p;
		}

		//iniciar sesion (devuelve null si falla; mira UltimoError)
		public static PerfilJugador Login(string usuario, string clave)
		{
			UltimoError = "";
			if (!Inicializar()) return null;

			try
			{
				string[] lineas = File.ReadAllLines(RutaJugadores());
				foreach (string linea in lineas)
				{
					string[] campos = linea.Split('|');
					if (campos.Length < 6) continue;

					if (campos[1].ToLower() == usuario.ToLower() && campos[2] == Hash(clave))
					{
						return LeerPerfil(campos);
					}
				}
			}
			catch (Exception ex)
			{
				UltimoError = ex.Message;
			}
			return null;
		}

		//registrar un jugador nuevo (devuelve "" si salio bien, o el mensaje de error)
		public static string Registrar(string usuario, string clave)
		{
			if (!Inicializar()) return "No se pudo crear la carpeta de datos";
			if (usuario.Contains("|")) return "El usuario no puede tener el caracter |";

			try
			{
				string[] lineas = File.ReadAllLines(RutaJugadores());
				int mayorId = 0;

				foreach (string linea in lineas)
				{
					string[] campos = linea.Split('|');
					if (campos.Length < 6) continue;

					if (campos[1].ToLower() == usuario.ToLower()) return "Ese usuario ya existe";

					int id = int.Parse(campos[0]);
					if (id > mayorId) mayorId = id;
				}

				string nueva = (mayorId + 1) + "|" + usuario + "|" + Hash(clave) + "|0|0|0";
				File.AppendAllText(RutaJugadores(), nueva + Environment.NewLine);
				return "";
			}
			catch (Exception ex)
			{
				return ex.Message;
			}
		}

		//guardar el equipo de un jugador (devuelve "" si salio bien)
		public static string GuardarEquipo(int jugadorId, List<DatosCarta> equipo)
		{
			if (!Inicializar()) return "No se pudo crear la carpeta de datos";

			try
			{
				//conservar los equipos de los demas jugadores
				List<string> nuevas = new List<string>();
				string[] lineas = File.ReadAllLines(RutaEquipos());
				foreach (string linea in lineas)
				{
					string[] campos = linea.Split('|');
					if (campos.Length >= 2 && campos[0] != jugadorId.ToString())
					{
						nuevas.Add(linea);
					}
				}

				//agregar el equipo nuevo
				List<string> ids = new List<string>();
				foreach (DatosCarta d in equipo)
				{
					ids.Add(d.Id.ToString());
				}
				nuevas.Add(jugadorId + "|" + string.Join(",", ids.ToArray()));

				File.WriteAllLines(RutaEquipos(), nuevas.ToArray());
				return "";
			}
			catch (Exception ex)
			{
				return ex.Message;
			}
		}

		//cargar el equipo guardado de un jugador (lista vacia si no tiene)
		public static List<DatosCarta> CargarEquipo(int jugadorId)
		{
			List<DatosCarta> equipo = new List<DatosCarta>();
			if (!Inicializar()) return equipo;

			try
			{
				string[] lineas = File.ReadAllLines(RutaEquipos());
				foreach (string linea in lineas)
				{
					string[] campos = linea.Split('|');
					if (campos.Length < 2 || campos[0] != jugadorId.ToString()) continue;

					//buscar cada carta por su Id
					string[] ids = campos[1].Split(',');
					foreach (string id in ids)
					{
						foreach (DatosCarta c in Catalogo.Obtener())
						{
							if (c.Id.ToString() == id)
							{
								equipo.Add(c);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				UltimoError = ex.Message;
			}
			return equipo;
		}

		//guardar el resultado de una partida (devuelve "" si salio bien)
		public static string RegistrarResultado(int jugadorId, string rival, bool victoria, int turnos, string archivoLog)
		{
			if (!Inicializar()) return "No se pudo crear la carpeta de datos";

			try
			{
				string resultado = "Derrota";
				if (victoria) resultado = "Victoria";

				//historial de la partida
				string fecha = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
				string historial = fecha + "|" + jugadorId + "|" + rival.Replace("|", "/") + "|" + resultado + "|" + turnos + "|" + archivoLog;
				File.AppendAllText(RutaPartidas(), historial + Environment.NewLine);

				//actualizar los totales del jugador
				string[] lineas = File.ReadAllLines(RutaJugadores());
				for (int i = 0; i < lineas.Length; i++)
				{
					string[] campos = lineas[i].Split('|');
					if (campos.Length < 6 || campos[0] != jugadorId.ToString()) continue;

					int partidas = int.Parse(campos[3]) + 1;
					int victorias = int.Parse(campos[4]);
					int derrotas = int.Parse(campos[5]);
					if (victoria) victorias++;
					else derrotas++;

					lineas[i] = campos[0] + "|" + campos[1] + "|" + campos[2] + "|" + partidas + "|" + victorias + "|" + derrotas;
				}
				File.WriteAllLines(RutaJugadores(), lineas);
				return "";
			}
			catch (Exception ex)
			{
				return ex.Message;
			}
		}

		//ranking de jugadores (mas victorias primero)
		public static List<PerfilJugador> ObtenerRanking()
		{
			List<PerfilJugador> lista = new List<PerfilJugador>();
			UltimoError = "";
			if (!Inicializar()) return lista;

			try
			{
				string[] lineas = File.ReadAllLines(RutaJugadores());
				foreach (string linea in lineas)
				{
					string[] campos = linea.Split('|');
					if (campos.Length < 6) continue;
					lista.Add(LeerPerfil(campos));
				}
			}
			catch (Exception ex)
			{
				UltimoError = ex.Message;
				return lista;
			}

			//ordenar de mayor a menor numero de victorias
			for (int i = 0; i < lista.Count - 1; i++)
			{
				for (int j = 0; j < lista.Count - 1 - i; j++)
				{
					bool intercambiar = lista[j].Victorias < lista[j + 1].Victorias;
					if (lista[j].Victorias == lista[j + 1].Victorias && lista[j].Partidas > lista[j + 1].Partidas)
					{
						intercambiar = true;
					}
					if (intercambiar)
					{
						PerfilJugador temporal = lista[j];
						lista[j] = lista[j + 1];
						lista[j + 1] = temporal;
					}
				}
			}
			return lista;
		}
	}
}
