﻿using System;
using System.Windows.Forms;

namespace ArenaElemental
{
	public partial class FormOpciones : Form
	{
		Form anterior;

		public FormOpciones()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_juego.png");

			//mostrar los valores actuales
			if (Configuracion.TiempoTurno == 15) cmbTiempo.SelectedIndex = 0;
			else if (Configuracion.TiempoTurno == 30) cmbTiempo.SelectedIndex = 2;
			else cmbTiempo.SelectedIndex = 1;

			if (Configuracion.EscenarioAlterno) cmbEscenario.SelectedIndex = 1;
			else cmbEscenario.SelectedIndex = 0;
		}

		public FormOpciones(Form menu) : this()
		{
			anterior = menu;
		}

		//guardar las opciones
		void GuardarOpciones()
		{
			if (cmbTiempo.SelectedIndex == 0) Configuracion.TiempoTurno = 15;
			else if (cmbTiempo.SelectedIndex == 2) Configuracion.TiempoTurno = 30;
			else Configuracion.TiempoTurno = 20;

			Configuracion.EscenarioAlterno = (cmbEscenario.SelectedIndex == 1);
		}

		//boton volver
		void BtnVolverClick(object sender, EventArgs e)
		{
			Close();
		}

		//al cerrar se guardan las opciones y se muestra el menu
		void FormOpcionesFormClosed(object sender, FormClosedEventArgs e)
		{
			GuardarOpciones();
			if (anterior != null) anterior.Show();
		}
	}
}
