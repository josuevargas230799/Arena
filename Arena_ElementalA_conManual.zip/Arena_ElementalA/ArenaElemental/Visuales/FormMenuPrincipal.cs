﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ArenaElemental
{
	public partial class FormMenuPrincipal : Form
	{
		//frases que aparecen junto al titulo (una distinta cada vez que se entra al menu)
		string[] frases = new string[]
		{
			"Solo los muertos han visto el final de la guerra. -Platon",
			"El hombre es un lobo para el hombre -Thomas Hobbes",
			"La guerra no es un fenómeno biológico, sino una invención social -Margaret Mead",
			"La guerra es un acto de violencia para obligar al oponente a hacer nuestra voluntad -Carl von Clausewitz",
			"La paz es solo un intervalo entre dos guerras -Anacarsis",
			"El conflicto es el padre de todas las cosas -Heraclito",
			"Los hombres hacen la guerra para obtener la paz -Aristoteles",
			"La guerra humaniza de forma destructiva -Claude Lévi-Strauss",
			"La guerra no es un instinto, sino un invento -Douglas Fry",
			"La civilización comenzó cuando el hombre inventó la propiedad y, con ella, la guerra -Jean-Jacques Rousseau",
			"El verdadero destructor de las culturas es el aislamiento, no el conflicto -Claude Lévi-Strauss",
			"La civilización comenzó cuando el hombre inventó la propiedad y, con ella, la guerra — Jean-Jacques Rousseau",
			"La guerra es un producto del exceso de orden social, no del caos — Pierre Clastres",
			"Toda la historia es la historia de la lucha de clases — Karl Marx",
			"La guerra... La guerra nunca cambia",
			"¡Sin bugs! (casi) - Andres"
		};

		static Random azar = new Random();
		string frase = "";
		int ultima = -1;
		float fase = 0;
		Timer timerFrase;
		Font fuenteGrande = new Font("Segoe Print", 14f, FontStyle.Bold);
		Font fuenteMedia = new Font("Segoe Print", 11f, FontStyle.Bold);
		Font fuentePequena = new Font("Segoe Print", 9f, FontStyle.Bold);
		Font fuenteFrase;   

		public FormMenuPrincipal()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_menu.png");

			//frase animada junto al titulo
			DoubleBuffered = true;
			timerFrase = new Timer();
			timerFrase.Interval = 40;
			timerFrase.Tick += new EventHandler(TimerFraseTick);
			VisibleChanged += new EventHandler(MenuVisibleChanged);
			Paint += new PaintEventHandler(MenuPaint);
		}

		//cada vez que el menu se muestra se elige otra frase
		void MenuVisibleChanged(object sender, EventArgs e)
		{
			if (Visible)
			{
				ElegirFrase();
				timerFrase.Start();
			}
			else
			{
				timerFrase.Stop();
			}
		}

		//elegir una frase distinta a la anterior
		void ElegirFrase()
		{
			int n = azar.Next(frases.Length);
			while (n == ultima && frases.Length > 1)
			{
				n = azar.Next(frases.Length);
			}
			ultima = n;
			frase = frases[n];
			if (frase.Length <= 30) fuenteFrase = fuenteGrande;
			else if (frase.Length <= 60) fuenteFrase = fuenteMedia;
			else fuenteFrase = fuentePequena;
		}

		//la frase late (crece y se encoge)
		void TimerFraseTick(object sender, EventArgs e)
		{
			fase = fase + 0.15f;
			Invalidate(new Rectangle(480, 20, 520, 230));
		}

		//dibujar la frase inclinada, en amarillo, como en Minecraft
		void MenuPaint(object sender, PaintEventArgs e)
		{
			if (frase == "") return;

			Graphics g = e.Graphics;
			g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

			float escala = 1.0f + 0.06f * (float)Math.Sin(fase);
						g.TranslateTransform(760, 115);
			g.RotateTransform(-15);
			g.ScaleTransform(escala, escala);

			//caja de 340 x 110 donde el texto se parte solo en renglones
			RectangleF caja = new RectangleF(-170, -55, 340, 110);
			RectangleF sombra = new RectangleF(-168, -53, 340, 110);

			using (StringFormat centro = new StringFormat())
			{
				centro.Alignment = StringAlignment.Center;
				centro.LineAlignment = StringAlignment.Center;
				g.DrawString(frase, fuenteFrase, Brushes.Black, sombra, centro);
				g.DrawString(frase, fuenteFrase, Brushes.Yellow, caja, centro);
			}
			g.ResetTransform();
		}

		//boton jugar
		void BtnJugarClick(object sender, EventArgs e)
		{
			IrA(new FormConfiguracion(this));
		}

		//boton cartas
		void BtnCartasClick(object sender, EventArgs e)
		{
			IrA(new FormCartas(this));
		}

		//boton reglas
		void BtnReglasClick(object sender, EventArgs e)
		{
			IrA(new FormReglas(this));
		}

		//boton ranking
		void BtnRankingClick(object sender, EventArgs e)
		{
			IrA(new FormRanking(this));
		}

		//boton opciones
		void BtnOpcionesClick(object sender, EventArgs e)
		{
			IrA(new FormOpciones(this));
		}

		//boton salir
		void BtnSalirClick(object sender, EventArgs e)
		{
			Application.Exit();
		}

		//abrir otro form y esconder este
		void IrA(Form f)
		{
			Hide();
			f.Show();
		}
	}
}