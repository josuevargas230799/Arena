﻿/*
 * Archivo del Designer de FormRanking
 */
namespace ArenaElemental
{
	partial class FormRanking
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.colPos = new System.Windows.Forms.ColumnHeader();
			this.colUsuario = new System.Windows.Forms.ColumnHeader();
			this.colPartidas = new System.Windows.Forms.ColumnHeader();
			this.colVictorias = new System.Windows.Forms.ColumnHeader();
			this.colDerrotas = new System.Windows.Forms.ColumnHeader();
			this.colExito = new System.Windows.Forms.ColumnHeader();
			this.lvRanking = new System.Windows.Forms.ListView();
			this.lblMensaje = new System.Windows.Forms.Label();
			this.btnVolver = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.AutoSize = false;
			this.lblTitulo.Location = new System.Drawing.Point(20, 10);
			this.lblTitulo.Size = new System.Drawing.Size(300, 45);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Text = "Ranking";
			this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// colPos
			// 
			this.colPos.Text = "#";
			this.colPos.Width = 50;
			// 
			// colUsuario
			// 
			this.colUsuario.Text = "Usuario";
			this.colUsuario.Width = 220;
			// 
			// colPartidas
			// 
			this.colPartidas.Text = "Partidas";
			this.colPartidas.Width = 105;
			// 
			// colVictorias
			// 
			this.colVictorias.Text = "Victorias";
			this.colVictorias.Width = 105;
			// 
			// colDerrotas
			// 
			this.colDerrotas.Text = "Derrotas";
			this.colDerrotas.Width = 105;
			// 
			// colExito
			// 
			this.colExito.Text = "% Éxito";
			this.colExito.Width = 105;
			// 
			// lvRanking
			// 
			this.lvRanking.Location = new System.Drawing.Point(150, 70);
			this.lvRanking.Size = new System.Drawing.Size(700, 420);
			this.lvRanking.Name = "lvRanking";
			this.lvRanking.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
						this.colPos,
						this.colUsuario,
						this.colPartidas,
						this.colVictorias,
						this.colDerrotas,
						this.colExito});
			this.lvRanking.FullRowSelect = true;
			this.lvRanking.UseCompatibleStateImageBehavior = false;
			this.lvRanking.View = System.Windows.Forms.View.Details;
			this.lvRanking.BackColor = System.Drawing.Color.FromArgb(235, 235, 228);
			this.lvRanking.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// lblMensaje
			// 
			this.lblMensaje.AutoSize = false;
			this.lblMensaje.Location = new System.Drawing.Point(150, 500);
			this.lblMensaje.Size = new System.Drawing.Size(700, 30);
			this.lblMensaje.Name = "lblMensaje";
			this.lblMensaje.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// btnVolver
			// 
			this.btnVolver.Location = new System.Drawing.Point(20, 540);
			this.btnVolver.Size = new System.Drawing.Size(130, 40);
			this.btnVolver.Name = "btnVolver";
			this.btnVolver.Text = "Volver";
			this.btnVolver.Click += new System.EventHandler(this.BtnVolverClick);
			// 
			// FormRanking
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.lvRanking);
			this.Controls.Add(this.lblMensaje);
			this.Controls.Add(this.btnVolver);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FormRanking";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Ranking";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormRankingFormClosed);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.ColumnHeader colPos;
		private System.Windows.Forms.ColumnHeader colUsuario;
		private System.Windows.Forms.ColumnHeader colPartidas;
		private System.Windows.Forms.ColumnHeader colVictorias;
		private System.Windows.Forms.ColumnHeader colDerrotas;
		private System.Windows.Forms.ColumnHeader colExito;
		private System.Windows.Forms.ListView lvRanking;
		private System.Windows.Forms.Label lblMensaje;
		private System.Windows.Forms.Button btnVolver;
	}
}
