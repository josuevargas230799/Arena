﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ArenaElemental
{
	//ventana que conecta las dos computadoras antes de empezar
	public partial class FormConexion : Form
	{
		bool esServidor = false;
		string ip = "";
		int puerto = 0;
		string miNombre = "";
		string misCartas = "";
		bool alternoLocal = false;

		//lo que se necesita al terminar
		public Red Conexion = new Red();
		public string NombreRival = "";
		public List<string> EquipoRival = new List<string>();
		public int Semilla = 1;
		public int Inicia = 1;
		public bool Alterno = false;

		bool conectado = false;
		bool holaRecibido = false;
		bool configRecibida = false;
		bool hayError = false;
		Timer timer;

		public FormConexion()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_juego.png");
		}

		public FormConexion(bool servidor, string ip, int puerto, string nombre, List<DatosCarta> equipo, bool alterno) : this()
		{
			esServidor = servidor;
			this.ip = ip;
			this.puerto = puerto;
			miNombre = nombre;
			alternoLocal = alterno;

			//mis cartas separadas por coma
			List<string> nombres = new List<string>();
			foreach (DatosCarta c in equipo)
			{
				nombres.Add(c.Nombre);
			}
			misCartas = string.Join(",", nombres.ToArray());

			//el servidor espera, el cliente se conecta
			if (esServidor)
			{
				try
				{
					Conexion.IniciarServidor(puerto);
					lblEstado.Text = "Esperando al rival...";
					lblInfo.Text = "Tu IP: " + Red.MiIp() + "   Puerto: " + puerto;
				}
				catch (Exception ex)
				{
					hayError = true;
					lblEstado.Text = "No se pudo abrir el puerto: " + ex.Message;
				}
			}
			else
			{
				lblEstado.Text = "Conectando con " + ip + "...";
				lblInfo.Text = "Puerto: " + puerto;
			}

			//revisar la conexion cada 300 ms
			timer = new Timer();
			timer.Interval = 300;
			timer.Tick += new EventHandler(TimerTick);
			if (!hayError) timer.Start();
		}

		//cada vez que pasa el tiempo se revisa que llego
		void TimerTick(object sender, EventArgs e)
		{
			try
			{
				if (!conectado)
				{
					if (esServidor)
					{
						if (!Conexion.AceptarSiHay()) return;
						conectado = true;
						lblEstado.Text = "Rival conectado, intercambiando datos...";

						//el servidor decide la semilla y quien empieza
						Random r = new Random();
						Semilla = r.Next(1, 100000);
						Inicia = r.Next(1, 3);
						Alterno = alternoLocal;
						Conexion.Enviar("HOLA|" + miNombre + "|" + misCartas);
						Conexion.Enviar("CONFIG|" + Semilla + "|" + Inicia + "|" + Bit(Alterno));
					}
					else
					{
						timer.Stop();
						Conexion.Conectar(ip, puerto);
						conectado = true;
						lblEstado.Text = "Conectado, intercambiando datos...";
						Conexion.Enviar("HOLA|" + miNombre + "|" + misCartas);
						timer.Start();
					}
					return;
				}

				//leer los mensajes que llegaron
				string linea = Conexion.Leer();
				while (linea != null)
				{
					Procesar(linea);
					linea = Conexion.Leer();
				}

				//el servidor solo necesita el HOLA del cliente; el cliente necesita HOLA y CONFIG
				bool listo = holaRecibido;
				if (!esServidor && !configRecibida) listo = false;

				if (listo)
				{
					timer.Stop();
					DialogResult = DialogResult.OK;
				}
			}
			catch (Exception ex)
			{
				timer.Stop();
				lblEstado.Text = "Error de conexión: " + ex.Message;
			}
		}

		//interpretar un mensaje
		void Procesar(string linea)
		{
			string[] partes = linea.Split('|');

			if (partes[0] == "HOLA" && partes.Length >= 3)
			{
				NombreRival = partes[1];
				if (NombreRival == miNombre) NombreRival = NombreRival + " (rival)";

				EquipoRival.Clear();
				string[] nombres = partes[2].Split(',');
				foreach (string n in nombres)
				{
					EquipoRival.Add(n);
				}
				holaRecibido = true;
			}
			else if (partes[0] == "CONFIG" && partes.Length >= 4)
			{
				Semilla = int.Parse(partes[1]);
				Inicia = int.Parse(partes[2]);
				Alterno = (partes[3] == "1");
				configRecibida = true;
			}
		}

		string Bit(bool valor)
		{
			if (valor) return "1";
			return "0";
		}

		//boton cancelar
		void BtnCancelarClick(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}

		//al cerrar sin conectar se cierra la red
		void FormConexionFormClosed(object sender, FormClosedEventArgs e)
		{
			if (timer != null) timer.Stop();
			if (DialogResult != DialogResult.OK)
			{
				Conexion.Cerrar();
			}
		}
	}
}
