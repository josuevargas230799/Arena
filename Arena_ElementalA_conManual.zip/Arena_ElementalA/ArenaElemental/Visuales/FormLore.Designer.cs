﻿/*
 * Archivo del Designer de FormLore
 */
namespace ArenaElemental
{
	partial class FormLore
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// FormLore
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.KeyPreview = true;
			this.Name = "FormLore";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Arena Elemental";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormLoreFormClosed);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormLoreKeyDown);
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormLoreMouseDown);
			this.ResumeLayout(false);
		}
	}
}