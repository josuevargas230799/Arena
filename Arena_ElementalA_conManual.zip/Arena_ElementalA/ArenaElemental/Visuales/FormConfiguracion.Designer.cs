﻿/*
 * Archivo del Designer de FormConfiguracion
 */
namespace ArenaElemental
{
	partial class FormConfiguracion
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.cmbTipo = new System.Windows.Forms.ComboBox();
			this.lstDisponibles = new System.Windows.Forms.ListBox();
			this.btnAgregar = new System.Windows.Forms.Button();
			this.btnQuitar = new System.Windows.Forms.Button();
			this.cmbModo = new System.Windows.Forms.ComboBox();
			this.lblIp = new System.Windows.Forms.Label();
			this.txtIp = new System.Windows.Forms.TextBox();
			this.lblPuerto = new System.Windows.Forms.Label();
			this.txtPuerto = new System.Windows.Forms.TextBox();
			this.lblSesion = new System.Windows.Forms.Label();
			this.cmbJugador = new System.Windows.Forms.ComboBox();
			this.lstSeleccionadas = new System.Windows.Forms.ListBox();
			this.lblConteo = new System.Windows.Forms.Label();
			this.btnSesion = new System.Windows.Forms.Button();
			this.btnGuardar = new System.Windows.Forms.Button();
			this.btnCargar = new System.Windows.Forms.Button();
			this.picPrevia = new System.Windows.Forms.PictureBox();
			this.lblDescripcion = new System.Windows.Forms.Label();
			this.btnVolver = new System.Windows.Forms.Button();
			this.btnIniciar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// cmbTipo
			// 
			this.cmbTipo.Location = new System.Drawing.Point(150, 60);
			this.cmbTipo.Size = new System.Drawing.Size(260, 30);
			this.cmbTipo.Name = "cmbTipo";
			this.cmbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTipo.Items.AddRange(new object[] {"Todos", "Fuego", "Agua", "Tierra", "Viento"});
			this.cmbTipo.SelectedIndexChanged += new System.EventHandler(this.CmbTipoSelectedIndexChanged);
			// 
			// lstDisponibles
			// 
			this.lstDisponibles.Location = new System.Drawing.Point(150, 100);
			this.lstDisponibles.Size = new System.Drawing.Size(260, 400);
			this.lstDisponibles.Name = "lstDisponibles";
			this.lstDisponibles.FormattingEnabled = true;
			this.lstDisponibles.BackColor = System.Drawing.Color.FromArgb(235, 235, 228);
			this.lstDisponibles.SelectedIndexChanged += new System.EventHandler(this.LstDisponiblesSelectedIndexChanged);
			// 
			// btnAgregar
			// 
			this.btnAgregar.Location = new System.Drawing.Point(430, 150);
			this.btnAgregar.Size = new System.Drawing.Size(100, 45);
			this.btnAgregar.Name = "btnAgregar";
			this.btnAgregar.Text = ">>";
			this.btnAgregar.Click += new System.EventHandler(this.BtnAgregarClick);
			// 
			// btnQuitar
			// 
			this.btnQuitar.Location = new System.Drawing.Point(430, 205);
			this.btnQuitar.Size = new System.Drawing.Size(100, 45);
			this.btnQuitar.Name = "btnQuitar";
			this.btnQuitar.Text = "<<";
			this.btnQuitar.Click += new System.EventHandler(this.BtnQuitarClick);
			// 
			// cmbModo
			// 
			this.cmbModo.Location = new System.Drawing.Point(430, 270);
			this.cmbModo.Size = new System.Drawing.Size(140, 30);
			this.cmbModo.Name = "cmbModo";
			this.cmbModo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbModo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmbModo.Items.AddRange(new object[] {"Local", "Contra máquina", "Red servidor", "Red cliente"});
			this.cmbModo.SelectedIndexChanged += new System.EventHandler(this.CmbModoSelectedIndexChanged);
			// 
			// lblIp
			// 
			this.lblIp.AutoSize = false;
			this.lblIp.Location = new System.Drawing.Point(430, 310);
			this.lblIp.Size = new System.Drawing.Size(140, 20);
			this.lblIp.Name = "lblIp";
			this.lblIp.Text = "IP del servidor";
			this.lblIp.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// txtIp
			// 
			this.txtIp.Location = new System.Drawing.Point(430, 330);
			this.txtIp.Size = new System.Drawing.Size(140, 26);
			this.txtIp.Name = "txtIp";
			this.txtIp.Text = "127.0.0.1";
			this.txtIp.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// lblPuerto
			// 
			this.lblPuerto.AutoSize = false;
			this.lblPuerto.Location = new System.Drawing.Point(430, 362);
			this.lblPuerto.Size = new System.Drawing.Size(140, 20);
			this.lblPuerto.Name = "lblPuerto";
			this.lblPuerto.Text = "Puerto";
			this.lblPuerto.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// txtPuerto
			// 
			this.txtPuerto.Location = new System.Drawing.Point(430, 382);
			this.txtPuerto.Size = new System.Drawing.Size(140, 26);
			this.txtPuerto.Name = "txtPuerto";
			this.txtPuerto.Text = "5000";
			this.txtPuerto.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// lblSesion
			// 
			this.lblSesion.AutoSize = false;
			this.lblSesion.Location = new System.Drawing.Point(580, 28);
			this.lblSesion.Size = new System.Drawing.Size(390, 28);
			this.lblSesion.Name = "lblSesion";
			this.lblSesion.Text = "Sesión: ninguna";
			this.lblSesion.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// cmbJugador
			// 
			this.cmbJugador.Location = new System.Drawing.Point(580, 60);
			this.cmbJugador.Size = new System.Drawing.Size(260, 30);
			this.cmbJugador.Name = "cmbJugador";
			this.cmbJugador.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbJugador.Items.AddRange(new object[] {"Jugador 1", "Jugador 2"});
			this.cmbJugador.SelectedIndexChanged += new System.EventHandler(this.CmbJugadorSelectedIndexChanged);
			// 
			// lstSeleccionadas
			// 
			this.lstSeleccionadas.Location = new System.Drawing.Point(580, 100);
			this.lstSeleccionadas.Size = new System.Drawing.Size(260, 150);
			this.lstSeleccionadas.Name = "lstSeleccionadas";
			this.lstSeleccionadas.FormattingEnabled = true;
			this.lstSeleccionadas.BackColor = System.Drawing.Color.FromArgb(235, 235, 228);
			this.lstSeleccionadas.SelectedIndexChanged += new System.EventHandler(this.LstSeleccionadasSelectedIndexChanged);
			// 
			// lblConteo
			// 
			this.lblConteo.AutoSize = false;
			this.lblConteo.Location = new System.Drawing.Point(850, 100);
			this.lblConteo.Size = new System.Drawing.Size(130, 28);
			this.lblConteo.Name = "lblConteo";
			this.lblConteo.Text = "Cartas: 0/5";
			this.lblConteo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// btnSesion
			// 
			this.btnSesion.Location = new System.Drawing.Point(850, 135);
			this.btnSesion.Size = new System.Drawing.Size(130, 38);
			this.btnSesion.Name = "btnSesion";
			this.btnSesion.Text = "Sesión";
			this.btnSesion.Click += new System.EventHandler(this.BtnSesionClick);
			// 
			// btnGuardar
			// 
			this.btnGuardar.Location = new System.Drawing.Point(850, 178);
			this.btnGuardar.Size = new System.Drawing.Size(130, 38);
			this.btnGuardar.Name = "btnGuardar";
			this.btnGuardar.Text = "Guardar";
			this.btnGuardar.Click += new System.EventHandler(this.BtnGuardarClick);
			// 
			// btnCargar
			// 
			this.btnCargar.Location = new System.Drawing.Point(850, 221);
			this.btnCargar.Size = new System.Drawing.Size(130, 38);
			this.btnCargar.Name = "btnCargar";
			this.btnCargar.Text = "Cargar";
			this.btnCargar.Click += new System.EventHandler(this.BtnCargarClick);
			// 
			// picPrevia
			// 
			this.picPrevia.Location = new System.Drawing.Point(580, 260);
			this.picPrevia.Size = new System.Drawing.Size(130, 180);
			this.picPrevia.Name = "picPrevia";
			this.picPrevia.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.picPrevia.BackColor = System.Drawing.Color.FromArgb(30, 35, 60);
			// 
			// lblDescripcion
			// 
			this.lblDescripcion.AutoSize = false;
			this.lblDescripcion.Location = new System.Drawing.Point(580, 450);
			this.lblDescripcion.Size = new System.Drawing.Size(390, 80);
			this.lblDescripcion.Name = "lblDescripcion";
			this.lblDescripcion.Text = "Descripción de la carta";
			this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// btnVolver
			// 
			this.btnVolver.Location = new System.Drawing.Point(20, 540);
			this.btnVolver.Size = new System.Drawing.Size(130, 40);
			this.btnVolver.Name = "btnVolver";
			this.btnVolver.Text = "Volver";
			this.btnVolver.Click += new System.EventHandler(this.BtnVolverClick);
			// 
			// btnIniciar
			// 
			this.btnIniciar.Location = new System.Drawing.Point(850, 540);
			this.btnIniciar.Size = new System.Drawing.Size(130, 40);
			this.btnIniciar.Name = "btnIniciar";
			this.btnIniciar.Text = "Iniciar";
			this.btnIniciar.Click += new System.EventHandler(this.BtnIniciarClick);
			// 
			// FormConfiguracion
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.Controls.Add(this.cmbTipo);
			this.Controls.Add(this.lstDisponibles);
			this.Controls.Add(this.btnAgregar);
			this.Controls.Add(this.btnQuitar);
			this.Controls.Add(this.cmbModo);
			this.Controls.Add(this.lblIp);
			this.Controls.Add(this.txtIp);
			this.Controls.Add(this.lblPuerto);
			this.Controls.Add(this.txtPuerto);
			this.Controls.Add(this.lblSesion);
			this.Controls.Add(this.cmbJugador);
			this.Controls.Add(this.lstSeleccionadas);
			this.Controls.Add(this.lblConteo);
			this.Controls.Add(this.btnSesion);
			this.Controls.Add(this.btnGuardar);
			this.Controls.Add(this.btnCargar);
			this.Controls.Add(this.picPrevia);
			this.Controls.Add(this.lblDescripcion);
			this.Controls.Add(this.btnVolver);
			this.Controls.Add(this.btnIniciar);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FormConfiguracion";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Configuración";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormConfiguracionFormClosed);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.ComboBox cmbTipo;
		private System.Windows.Forms.ListBox lstDisponibles;
		private System.Windows.Forms.Button btnAgregar;
		private System.Windows.Forms.Button btnQuitar;
		private System.Windows.Forms.ComboBox cmbModo;
		private System.Windows.Forms.Label lblIp;
		private System.Windows.Forms.TextBox txtIp;
		private System.Windows.Forms.Label lblPuerto;
		private System.Windows.Forms.TextBox txtPuerto;
		private System.Windows.Forms.Label lblSesion;
		private System.Windows.Forms.ComboBox cmbJugador;
		private System.Windows.Forms.ListBox lstSeleccionadas;
		private System.Windows.Forms.Label lblConteo;
		private System.Windows.Forms.Button btnSesion;
		private System.Windows.Forms.Button btnGuardar;
		private System.Windows.Forms.Button btnCargar;
		private System.Windows.Forms.PictureBox picPrevia;
		private System.Windows.Forms.Label lblDescripcion;
		private System.Windows.Forms.Button btnVolver;
		private System.Windows.Forms.Button btnIniciar;
	}
}
