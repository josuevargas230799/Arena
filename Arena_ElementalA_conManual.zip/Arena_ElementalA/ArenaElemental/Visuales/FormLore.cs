﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ArenaElemental
{
	//prologo del juego: cielo estrellado y un texto que aparece poco a poco
	public partial class FormLore : Form
	{
		//texto del prologo: cada elemento es una pantalla de texto (\n salta de renglon)
		//la ultima se muestra mas grande, como titulo
				string[] frases = new string[]
		{
			"Durante siglos, el majestuoso reino de Aethelgard\nconoció una paz inquebrantable bajo la luz\nde una única fe: la Hazthelgord.",
			"Toda la población, desde los campesinos\nhasta los reyes, adoraba al Hacedor,\nla entidad divina que había tejido el mundo.",
			"El Hacedor depositó en manos de los mortales\nun regalo sagrado: el dominio sobre los cuatro\nelementos fundamentales de la creación.",
			"Nacer con la capacidad de manipular\nel viento, el agua, la tierra o el fuego\nera una bendición del Hacedor.",
			"Una herramienta divina para proteger la vida,\ncultivar la tierra y mantener el equilibrio natural,\nantes de devolver ese poder al morir.",
			"La tragedia que fracturó este paraíso\nno nació de la magia,\nsino del dogma y la ambición humana.",
			"El punto de quiebre ocurrió durante la excavación\nde la Cripta del Origen, el primer templo\nconstruido por la humanidad\nen los albores del tiempo.",
			"Allí, el Sumo Erudito Kaelen,\nun maestro respetado por todo el reino,\ndescubrió los fragmentos de las\nEscrituras Primordiales.",
			"Al traducir estos textos olvidados,\nKaelen encontró una revelación\nque sacudiría los cimientos del mundo.",
			"Las escrituras afirmaban que el Hacedor\nno exigía sumisión, sino evolución.",
			"Según la traducción de Kaelen, los elementos\nno eran herramientas para servir y morir,\nsino las llaves para que la humanidad\ntrascendiera y alcanzara la inmortalidad.",
			"La humanidad se convertiría en sus propios dioses,\ngobernando el plano terrenal\nsin depender de ninguna deidad.",
			"Cuando Kaelen presentó esta verdad ante el cónclave,\nla Gran Matriarca Seline la declaró\nla máxima herejía.",
			"Para ella y los altos sacerdotes,\nintentar ascender a la divinidad\nera un acto de arrogancia suprema\nque traería la ira del Hacedor\ny la destrucción del mundo.",
			"Seline ordenó la ejecución inmediata de Kaelen\ny la quema de los textos,\npero las palabras del erudito ya habían encendido\nuna chispa en la mente de millones.",
			"La noche de la ejecución,\nlos seguidores de Kaelen se levantaron en armas,\nliberaron a su líder y tiñeron los escalones\ndel templo sagrado con la sangre\nde sus propios hermanos.",
			"Esa noche, Aethelgard se partió\nen dos mitades irreconciliables.",
			"Por un lado se alzaron Los Custodios del Velo,\nfieles a la Matriarca Seline\ny a la doctrina original.",
			"Ellos creen firmemente en la humildad,\nel servicio y la preservación del orden divino.",
			"Consideran a sus enemigos como almas\ncorruptas por la soberbia que deben ser purgadas\npara salvar al mundo del castigo de los dioses.",
			"Por el otro lado surgieron Los Hijos del Apogeo,\nliderados por Kaelen.",
			"Su fe es feroz y progresista;\nestán convencidos de que cumplen\nel verdadero plan cósmico y de que cada vida\nsacrificada es un paso necesario\nhacia la gloriosa evolución de la humanidad.",
			"La guerra que asola el continente\nes una de las más crueles jamás vistas,\nprecisamente porque la magia no tiene bando.",
			"En los campos de batalla de Aethelgard,\nun piromante de los Custodios incinera\na un maestro del fuego del Apogeo,",
			"mientras que los escudos de roca\nde un geomante tradicionalista chocan violentamente\ncontra las lanzas de tierra de un geomante rebelde.",
			"El agua cura y ahoga a ambos lados por igual,\ny el viento transporta los himnos de guerra\nde dos facciones que rezan a la misma fe,\npero luchan por un futuro completamente distinto.",
			"Ahora, con el reino dividido\npor una gigantesca cicatriz de tierra quemada\ny ciudades en ruinas,",
			"el jugador debe decidir\nqué destino merece la humanidad:\nla redención a través de la devoción,\no la libertad a costa de la herejía.",
			"ARENA ELEMENTAL"
		};

		//duraciones en milisegundos
		const int APARECER = 1600;
		const int MANTENER = 3200;
		const int DESVANECER = 1600;
		const int PAUSA = 800;
		const int TOTAL = APARECER + MANTENER + DESVANECER + PAUSA;
		const int ENTRADA = 1500;   //el cielo aparece desde negro
		const int SALIDA = 1200;    //al final todo se funde a negro

		//estrellas
		const int NUM_ESTRELLAS = 170;
		float[] estX = new float[NUM_ESTRELLAS];
		float[] estY = new float[NUM_ESTRELLAS];
		float[] estTam = new float[NUM_ESTRELLAS];
		float[] estFase = new float[NUM_ESTRELLAS];
		float[] estVel = new float[NUM_ESTRELLAS];
		Random azar = new Random();

		Timer timer;
		Font fuenteTexto;
		Font fuenteTitulo;
		Font fuenteAyuda;

		int ultimoTick;
		int transcurrido = 0;         //ms desde que se abrio
		int indice = 0;         //frase actual
		int tiempo = 0;         //ms de la frase actual
		int salida = 0;         //ms desde que empezo la salida
		bool saliendo = false;
		float fase = 0;         //para el parpadeo de las estrellas

		public FormLore()
		{
			InitializeComponent();

			//evita parpadeos al dibujar
			SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);

			fuenteTexto = new Font("Segoe Print", 20f);
			fuenteTitulo = new Font("Segoe Print", 40f, FontStyle.Bold);
			fuenteAyuda = new Font("Segoe UI", 9f);

			CrearEstrellas();

			timer = new Timer();
			timer.Interval = 30;
			timer.Tick += new EventHandler(TimerTick);
			ultimoTick = Environment.TickCount;
			timer.Start();
		}

		//posiciones al azar de las estrellas
		void CrearEstrellas()
		{
			for (int i = 0; i < NUM_ESTRELLAS; i++)
			{
				estX[i] = azar.Next(ClientSize.Width);
				estY[i] = azar.Next(ClientSize.Height);
				estTam[i] = 0.8f + (float)azar.NextDouble() * 1.8f;
				estFase[i] = (float)(azar.NextDouble() * 6.28);
				estVel[i] = 0.6f + (float)azar.NextDouble() * 1.6f;
			}
		}

		//cada 30 ms: avanzar la animacion
		void TimerTick(object sender, EventArgs e)
		{
			int ahora = Environment.TickCount;
			int dt = ahora - ultimoTick;
			ultimoTick = ahora;
			if (dt < 0) dt = 0;
			if (dt > 200) dt = 200;     //por si la ventana se congelo un momento

			transcurrido += dt;
			fase += dt / 1000f;

			//las estrellas se mueven muy despacio hacia la izquierda
			for (int i = 0; i < NUM_ESTRELLAS; i++)
			{
				estX[i] -= estTam[i] * 6f * dt / 1000f;
				if (estX[i] < 0) estX[i] += ClientSize.Width;
			}

			if (saliendo)
			{
				salida += dt;
				if (salida >= SALIDA)
				{
					timer.Stop();
					Close();
					return;
				}
			}
			else if (transcurrido > ENTRADA)
			{
				tiempo += dt;
				if (tiempo >= TOTAL)
				{
					tiempo = 0;
					indice++;
					if (indice >= frases.Length) saliendo = true;
				}
			}

			Invalidate();
		}

		//transparencia del texto (aparece, se queda y se desvanece)
		int AlfaTexto()
		{
			int alfa;
			if (tiempo < APARECER) alfa = 255 * tiempo / APARECER;
			else if (tiempo < APARECER + MANTENER) alfa = 255;
			else alfa = 255 - 255 * (tiempo - APARECER - MANTENER) / DESVANECER;

			if (alfa < 0) alfa = 0;
			if (alfa > 255) alfa = 255;
			return alfa;
		}

		//dibujar el cielo, las estrellas y el texto
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			int w = ClientSize.Width;
			int h = ClientSize.Height;
			if (w <= 0 || h <= 0) return;

			g.SmoothingMode = SmoothingMode.AntiAlias;
			g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

			//cielo: oscuro arriba y un poco mas claro abajo
			using (LinearGradientBrush cielo = new LinearGradientBrush(new Rectangle(0, 0, w, h), Color.FromArgb(3, 4, 14), Color.FromArgb(22, 24, 52), 90f))
			{
				g.FillRectangle(cielo, 0, 0, w, h);
			}

			//estrellas (cada una parpadea a su ritmo)
			using (SolidBrush pincel = new SolidBrush(Color.White))
			{
				for (int i = 0; i < NUM_ESTRELLAS; i++)
				{
					double brillo = 0.55 + 0.45 * Math.Sin(fase * estVel[i] * 2 + estFase[i]);
					int alfa = (int)(255 * brillo);
					if (alfa < 30) alfa = 30;
					if (alfa > 255) alfa = 255;

					pincel.Color = Color.FromArgb(alfa, 225, 232, 255);
					g.FillEllipse(pincel, estX[i], estY[i], estTam[i], estTam[i]);

					//las mas grandes tienen un brillo suave alrededor
					if (estTam[i] > 2.2f)
					{
						pincel.Color = Color.FromArgb(alfa / 5, 200, 215, 255);
						g.FillEllipse(pincel, estX[i] - estTam[i], estY[i] - estTam[i], estTam[i] * 3, estTam[i] * 3);
					}
				}
			}

			//texto del prologo
			if (transcurrido > ENTRADA && indice < frases.Length)
			{
				int alfa = AlfaTexto();
				if (alfa > 0)
				{
					Font fuente = fuenteTexto;
					if (indice == frases.Length - 1) fuente = fuenteTitulo;

					using (StringFormat centro = new StringFormat())
					using (SolidBrush texto = new SolidBrush(Color.FromArgb(alfa, 240, 240, 255)))
					{
						centro.Alignment = StringAlignment.Center;
						centro.LineAlignment = StringAlignment.Center;
						g.DrawString(frases[indice], fuente, texto, new RectangleF(60, 150, w - 120, 300), centro);
					}
				}

				//aviso para saltar
				using (StringFormat derecha = new StringFormat())
				using (SolidBrush ayuda = new SolidBrush(Color.FromArgb(110, 200, 205, 230)))
				{
					derecha.Alignment = StringAlignment.Far;
					g.DrawString("Presiona cualquier tecla para saltar", fuenteAyuda, ayuda, new RectangleF(0, h - 35, w - 20, 25), derecha);
				}
			}

			//negro: al empezar el cielo aparece poco a poco y al final se funde
			int negro = 0;
			if (transcurrido < ENTRADA) negro = 255 - 255 * transcurrido / ENTRADA;
			if (saliendo)
			{
				int n2 = 255 * salida / SALIDA;
				if (n2 > negro) negro = n2;
			}
			if (negro > 255) negro = 255;
			if (negro > 0)
			{
				using (SolidBrush fondo = new SolidBrush(Color.FromArgb(negro, 0, 0, 0)))
				{
					g.FillRectangle(fondo, 0, 0, w, h);
				}
			}
		}

		//saltar el prologo
		void Saltar()
		{
			if (!saliendo)
			{
				saliendo = true;
				salida = 0;
			}
		}

		void FormLoreKeyDown(object sender, KeyEventArgs e)
		{
			Saltar();
		}

		void FormLoreMouseDown(object sender, MouseEventArgs e)
		{
			Saltar();
		}

		//al cerrar se libera lo que se creo
		void FormLoreFormClosed(object sender, FormClosedEventArgs e)
		{
			timer.Stop();
			timer.Dispose();
			fuenteTexto.Dispose();
			fuenteTitulo.Dispose();
			fuenteAyuda.Dispose();
		}
	}
}