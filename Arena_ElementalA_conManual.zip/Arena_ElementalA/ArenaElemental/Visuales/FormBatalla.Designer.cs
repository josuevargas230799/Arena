﻿/*
 * Archivo del Designer de FormBatalla
 */
namespace ArenaElemental
{
	partial class FormBatalla
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblEscenario = new System.Windows.Forms.Label();
			this.lblReloj = new System.Windows.Forms.Label();
			this.panelJ1 = new System.Windows.Forms.Panel();
			this.lblJugador1 = new System.Windows.Forms.Label();
			this.picJ1 = new System.Windows.Forms.PictureBox();
			this.lblNombreJ1 = new System.Windows.Forms.Label();
			this.lblVida1 = new System.Windows.Forms.Label();
			this.barVida1 = new System.Windows.Forms.ProgressBar();
			this.lblEscudo1 = new System.Windows.Forms.Label();
			this.barEscudo1 = new System.Windows.Forms.ProgressBar();
			this.lblEnergia1 = new System.Windows.Forms.Label();
			this.barEnergia1 = new System.Windows.Forms.ProgressBar();
			this.lblEspecial1 = new System.Windows.Forms.Label();
			this.barEspecial1 = new System.Windows.Forms.ProgressBar();
			this.panelJ2 = new System.Windows.Forms.Panel();
			this.lblJugador2 = new System.Windows.Forms.Label();
			this.picJ2 = new System.Windows.Forms.PictureBox();
			this.lblNombreJ2 = new System.Windows.Forms.Label();
			this.lblVida2 = new System.Windows.Forms.Label();
			this.barVida2 = new System.Windows.Forms.ProgressBar();
			this.lblEscudo2 = new System.Windows.Forms.Label();
			this.barEscudo2 = new System.Windows.Forms.ProgressBar();
			this.lblEnergia2 = new System.Windows.Forms.Label();
			this.barEnergia2 = new System.Windows.Forms.ProgressBar();
			this.lblEspecial2 = new System.Windows.Forms.Label();
			this.barEspecial2 = new System.Windows.Forms.ProgressBar();
			this.panelMovimiento = new System.Windows.Forms.Panel();
			this.lblMovimientoTitulo = new System.Windows.Forms.Label();
			this.lblMovimiento = new System.Windows.Forms.Label();
			this.lblBitacora = new System.Windows.Forms.Label();
			this.lstBitacora = new System.Windows.Forms.ListBox();
			this.chkRelevar = new System.Windows.Forms.CheckBox();
			this.chkDefender = new System.Windows.Forms.CheckBox();
			this.chkHabilidad = new System.Windows.Forms.CheckBox();
			this.chkAtacar = new System.Windows.Forms.CheckBox();
			this.btnEjecutar = new System.Windows.Forms.Button();
			this.lblTurno = new System.Windows.Forms.Label();
			this.lblBanca1 = new System.Windows.Forms.Label();
			this.lstBanca1 = new System.Windows.Forms.ListBox();
			this.lblBanca2 = new System.Windows.Forms.Label();
			this.lstBanca2 = new System.Windows.Forms.ListBox();
			this.btnVolver = new System.Windows.Forms.Button();
			this.panelJ1.SuspendLayout();
			this.panelJ2.SuspendLayout();
			this.panelMovimiento.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblEscenario
			// 
			this.lblEscenario.AutoSize = false;
			this.lblEscenario.Location = new System.Drawing.Point(20, 10);
			this.lblEscenario.Size = new System.Drawing.Size(700, 35);
			this.lblEscenario.Name = "lblEscenario";
			this.lblEscenario.Text = "Escenario";
			// 
			// lblReloj
			// 
			this.lblReloj.AutoSize = false;
			this.lblReloj.Location = new System.Drawing.Point(880, 10);
			this.lblReloj.Size = new System.Drawing.Size(200, 35);
			this.lblReloj.Name = "lblReloj";
			this.lblReloj.Text = "Tiempo: 00:20";
			this.lblReloj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panelJ1
			// 
			this.panelJ1.Location = new System.Drawing.Point(20, 55);
			this.panelJ1.Size = new System.Drawing.Size(300, 350);
			this.panelJ1.Name = "panelJ1";
			this.panelJ1.BackColor = System.Drawing.Color.FromArgb(30, 35, 60);
			// 
			// lblJugador1
			// 
			this.lblJugador1.AutoSize = false;
			this.lblJugador1.Location = new System.Drawing.Point(10, 5);
			this.lblJugador1.Size = new System.Drawing.Size(280, 28);
			this.lblJugador1.Name = "lblJugador1";
			this.lblJugador1.Text = "Jugador 1";
			this.lblJugador1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// picJ1
			// 
			this.picJ1.Location = new System.Drawing.Point(75, 35);
			this.picJ1.Size = new System.Drawing.Size(130, 180);
			this.picJ1.Name = "picJ1";
			this.picJ1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			// 
			// lblNombreJ1
			// 
			this.lblNombreJ1.AutoSize = false;
			this.lblNombreJ1.Location = new System.Drawing.Point(10, 220);
			this.lblNombreJ1.Size = new System.Drawing.Size(280, 28);
			this.lblNombreJ1.Name = "lblNombreJ1";
			this.lblNombreJ1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblVida1
			// 
			this.lblVida1.AutoSize = false;
			this.lblVida1.Location = new System.Drawing.Point(10, 255);
			this.lblVida1.Size = new System.Drawing.Size(105, 22);
			this.lblVida1.Name = "lblVida1";
			this.lblVida1.Text = "Vida";
			this.lblVida1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barVida1
			// 
			this.barVida1.Location = new System.Drawing.Point(120, 258);
			this.barVida1.Size = new System.Drawing.Size(165, 16);
			this.barVida1.Name = "barVida1";
			// 
			// lblEscudo1
			// 
			this.lblEscudo1.AutoSize = false;
			this.lblEscudo1.Location = new System.Drawing.Point(10, 278);
			this.lblEscudo1.Size = new System.Drawing.Size(105, 22);
			this.lblEscudo1.Name = "lblEscudo1";
			this.lblEscudo1.Text = "Escudo";
			this.lblEscudo1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barEscudo1
			// 
			this.barEscudo1.Location = new System.Drawing.Point(120, 281);
			this.barEscudo1.Size = new System.Drawing.Size(165, 16);
			this.barEscudo1.Name = "barEscudo1";
			// 
			// lblEnergia1
			// 
			this.lblEnergia1.AutoSize = false;
			this.lblEnergia1.Location = new System.Drawing.Point(10, 301);
			this.lblEnergia1.Size = new System.Drawing.Size(105, 22);
			this.lblEnergia1.Name = "lblEnergia1";
			this.lblEnergia1.Text = "Energia";
			this.lblEnergia1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barEnergia1
			// 
			this.barEnergia1.Location = new System.Drawing.Point(120, 304);
			this.barEnergia1.Size = new System.Drawing.Size(165, 16);
			this.barEnergia1.Name = "barEnergia1";
			// 
			// lblEspecial1
			// 
			this.lblEspecial1.AutoSize = false;
			this.lblEspecial1.Location = new System.Drawing.Point(10, 324);
			this.lblEspecial1.Size = new System.Drawing.Size(105, 22);
			this.lblEspecial1.Name = "lblEspecial1";
			this.lblEspecial1.Text = "Especial";
			this.lblEspecial1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barEspecial1
			// 
			this.barEspecial1.Location = new System.Drawing.Point(120, 327);
			this.barEspecial1.Size = new System.Drawing.Size(165, 16);
			this.barEspecial1.Name = "barEspecial1";
			// 
			// panelJ2
			// 
			this.panelJ2.Location = new System.Drawing.Point(780, 55);
			this.panelJ2.Size = new System.Drawing.Size(300, 350);
			this.panelJ2.Name = "panelJ2";
			this.panelJ2.BackColor = System.Drawing.Color.FromArgb(30, 35, 60);
			// 
			// lblJugador2
			// 
			this.lblJugador2.AutoSize = false;
			this.lblJugador2.Location = new System.Drawing.Point(10, 5);
			this.lblJugador2.Size = new System.Drawing.Size(280, 28);
			this.lblJugador2.Name = "lblJugador2";
			this.lblJugador2.Text = "Jugador 2";
			this.lblJugador2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// picJ2
			// 
			this.picJ2.Location = new System.Drawing.Point(75, 35);
			this.picJ2.Size = new System.Drawing.Size(130, 180);
			this.picJ2.Name = "picJ2";
			this.picJ2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			// 
			// lblNombreJ2
			// 
			this.lblNombreJ2.AutoSize = false;
			this.lblNombreJ2.Location = new System.Drawing.Point(10, 220);
			this.lblNombreJ2.Size = new System.Drawing.Size(280, 28);
			this.lblNombreJ2.Name = "lblNombreJ2";
			this.lblNombreJ2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblVida2
			// 
			this.lblVida2.AutoSize = false;
			this.lblVida2.Location = new System.Drawing.Point(10, 255);
			this.lblVida2.Size = new System.Drawing.Size(105, 22);
			this.lblVida2.Name = "lblVida2";
			this.lblVida2.Text = "Vida";
			this.lblVida2.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barVida2
			// 
			this.barVida2.Location = new System.Drawing.Point(120, 258);
			this.barVida2.Size = new System.Drawing.Size(165, 16);
			this.barVida2.Name = "barVida2";
			// 
			// lblEscudo2
			// 
			this.lblEscudo2.AutoSize = false;
			this.lblEscudo2.Location = new System.Drawing.Point(10, 278);
			this.lblEscudo2.Size = new System.Drawing.Size(105, 22);
			this.lblEscudo2.Name = "lblEscudo2";
			this.lblEscudo2.Text = "Escudo";
			this.lblEscudo2.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barEscudo2
			// 
			this.barEscudo2.Location = new System.Drawing.Point(120, 281);
			this.barEscudo2.Size = new System.Drawing.Size(165, 16);
			this.barEscudo2.Name = "barEscudo2";
			// 
			// lblEnergia2
			// 
			this.lblEnergia2.AutoSize = false;
			this.lblEnergia2.Location = new System.Drawing.Point(10, 301);
			this.lblEnergia2.Size = new System.Drawing.Size(105, 22);
			this.lblEnergia2.Name = "lblEnergia2";
			this.lblEnergia2.Text = "Energia";
			this.lblEnergia2.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barEnergia2
			// 
			this.barEnergia2.Location = new System.Drawing.Point(120, 304);
			this.barEnergia2.Size = new System.Drawing.Size(165, 16);
			this.barEnergia2.Name = "barEnergia2";
			// 
			// lblEspecial2
			// 
			this.lblEspecial2.AutoSize = false;
			this.lblEspecial2.Location = new System.Drawing.Point(10, 324);
			this.lblEspecial2.Size = new System.Drawing.Size(105, 22);
			this.lblEspecial2.Name = "lblEspecial2";
			this.lblEspecial2.Text = "Especial";
			this.lblEspecial2.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// barEspecial2
			// 
			this.barEspecial2.Location = new System.Drawing.Point(120, 327);
			this.barEspecial2.Size = new System.Drawing.Size(165, 16);
			this.barEspecial2.Name = "barEspecial2";
			// 
			// panelMovimiento
			// 
			this.panelMovimiento.Location = new System.Drawing.Point(340, 55);
			this.panelMovimiento.Size = new System.Drawing.Size(400, 160);
			this.panelMovimiento.Name = "panelMovimiento";
			this.panelMovimiento.BackColor = System.Drawing.Color.FromArgb(30, 35, 60);
			// 
			// lblMovimientoTitulo
			// 
			this.lblMovimientoTitulo.AutoSize = false;
			this.lblMovimientoTitulo.Location = new System.Drawing.Point(10, 6);
			this.lblMovimientoTitulo.Size = new System.Drawing.Size(380, 26);
			this.lblMovimientoTitulo.Name = "lblMovimientoTitulo";
			this.lblMovimientoTitulo.Text = "Último movimiento";
			this.lblMovimientoTitulo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// lblMovimiento
			// 
			this.lblMovimiento.AutoSize = false;
			this.lblMovimiento.Location = new System.Drawing.Point(10, 36);
			this.lblMovimiento.Size = new System.Drawing.Size(380, 118);
			this.lblMovimiento.Name = "lblMovimiento";
			this.lblMovimiento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// lblBitacora
			// 
			this.lblBitacora.AutoSize = false;
			this.lblBitacora.Location = new System.Drawing.Point(340, 222);
			this.lblBitacora.Size = new System.Drawing.Size(400, 24);
			this.lblBitacora.Name = "lblBitacora";
			this.lblBitacora.Text = "Bitácora";
			// 
			// lstBitacora
			// 
			this.lstBitacora.Location = new System.Drawing.Point(340, 248);
			this.lstBitacora.Size = new System.Drawing.Size(400, 157);
			this.lstBitacora.Name = "lstBitacora";
			this.lstBitacora.FormattingEnabled = true;
			this.lstBitacora.BackColor = System.Drawing.Color.FromArgb(235, 235, 228);
			this.lstBitacora.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// chkRelevar
			// 
			this.chkRelevar.AutoSize = false;
			this.chkRelevar.Location = new System.Drawing.Point(340, 412);
			this.chkRelevar.Size = new System.Drawing.Size(97, 42);
			this.chkRelevar.Name = "chkRelevar";
			this.chkRelevar.Text = "Relevar (1)";
			this.chkRelevar.Appearance = System.Windows.Forms.Appearance.Button;
			this.chkRelevar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.chkRelevar.UseVisualStyleBackColor = false;
			this.chkRelevar.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// chkDefender
			// 
			this.chkDefender.AutoSize = false;
			this.chkDefender.Location = new System.Drawing.Point(441, 412);
			this.chkDefender.Size = new System.Drawing.Size(97, 42);
			this.chkDefender.Name = "chkDefender";
			this.chkDefender.Text = "Defender (1)";
			this.chkDefender.Appearance = System.Windows.Forms.Appearance.Button;
			this.chkDefender.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.chkDefender.UseVisualStyleBackColor = false;
			this.chkDefender.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// chkHabilidad
			// 
			this.chkHabilidad.AutoSize = false;
			this.chkHabilidad.Location = new System.Drawing.Point(542, 412);
			this.chkHabilidad.Size = new System.Drawing.Size(97, 42);
			this.chkHabilidad.Name = "chkHabilidad";
			this.chkHabilidad.Text = "Habilidad (2)";
			this.chkHabilidad.Appearance = System.Windows.Forms.Appearance.Button;
			this.chkHabilidad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.chkHabilidad.UseVisualStyleBackColor = false;
			this.chkHabilidad.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// chkAtacar
			// 
			this.chkAtacar.AutoSize = false;
			this.chkAtacar.Location = new System.Drawing.Point(643, 412);
			this.chkAtacar.Size = new System.Drawing.Size(97, 42);
			this.chkAtacar.Name = "chkAtacar";
			this.chkAtacar.Text = "Atacar (1)";
			this.chkAtacar.Appearance = System.Windows.Forms.Appearance.Button;
			this.chkAtacar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.chkAtacar.UseVisualStyleBackColor = false;
			this.chkAtacar.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// btnEjecutar
			// 
			this.btnEjecutar.Location = new System.Drawing.Point(340, 460);
			this.btnEjecutar.Size = new System.Drawing.Size(400, 42);
			this.btnEjecutar.Name = "btnEjecutar";
			this.btnEjecutar.Text = "Ejecutar turno";
			this.btnEjecutar.Click += new System.EventHandler(this.BtnEjecutarClick);
			// 
			// lblTurno
			// 
			this.lblTurno.AutoSize = false;
			this.lblTurno.Location = new System.Drawing.Point(340, 508);
			this.lblTurno.Size = new System.Drawing.Size(400, 62);
			this.lblTurno.Name = "lblTurno";
			this.lblTurno.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTurno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblBanca1
			// 
			this.lblBanca1.AutoSize = false;
			this.lblBanca1.Location = new System.Drawing.Point(20, 420);
			this.lblBanca1.Size = new System.Drawing.Size(300, 28);
			this.lblBanca1.Name = "lblBanca1";
			this.lblBanca1.Text = "Banca Jugador 1";
			// 
			// lstBanca1
			// 
			this.lstBanca1.Location = new System.Drawing.Point(20, 450);
			this.lstBanca1.Size = new System.Drawing.Size(300, 125);
			this.lstBanca1.Name = "lstBanca1";
			this.lstBanca1.FormattingEnabled = true;
			this.lstBanca1.BackColor = System.Drawing.Color.FromArgb(235, 235, 228);
			this.lstBanca1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// lblBanca2
			// 
			this.lblBanca2.AutoSize = false;
			this.lblBanca2.Location = new System.Drawing.Point(780, 420);
			this.lblBanca2.Size = new System.Drawing.Size(300, 28);
			this.lblBanca2.Name = "lblBanca2";
			this.lblBanca2.Text = "Banca Jugador 2";
			// 
			// lstBanca2
			// 
			this.lstBanca2.Location = new System.Drawing.Point(780, 450);
			this.lstBanca2.Size = new System.Drawing.Size(300, 125);
			this.lstBanca2.Name = "lstBanca2";
			this.lstBanca2.FormattingEnabled = true;
			this.lstBanca2.BackColor = System.Drawing.Color.FromArgb(235, 235, 228);
			this.lstBanca2.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// btnVolver
			// 
			this.btnVolver.Location = new System.Drawing.Point(20, 590);
			this.btnVolver.Size = new System.Drawing.Size(130, 40);
			this.btnVolver.Name = "btnVolver";
			this.btnVolver.Text = "Volver";
			this.btnVolver.Click += new System.EventHandler(this.BtnVolverClick);
			// 
			// FormBatalla
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(1100, 640);
			this.panelJ1.Controls.Add(this.lblJugador1);
			this.panelJ1.Controls.Add(this.picJ1);
			this.panelJ1.Controls.Add(this.lblNombreJ1);
			this.panelJ1.Controls.Add(this.lblVida1);
			this.panelJ1.Controls.Add(this.barVida1);
			this.panelJ1.Controls.Add(this.lblEscudo1);
			this.panelJ1.Controls.Add(this.barEscudo1);
			this.panelJ1.Controls.Add(this.lblEnergia1);
			this.panelJ1.Controls.Add(this.barEnergia1);
			this.panelJ1.Controls.Add(this.lblEspecial1);
			this.panelJ1.Controls.Add(this.barEspecial1);
			this.panelJ2.Controls.Add(this.lblJugador2);
			this.panelJ2.Controls.Add(this.picJ2);
			this.panelJ2.Controls.Add(this.lblNombreJ2);
			this.panelJ2.Controls.Add(this.lblVida2);
			this.panelJ2.Controls.Add(this.barVida2);
			this.panelJ2.Controls.Add(this.lblEscudo2);
			this.panelJ2.Controls.Add(this.barEscudo2);
			this.panelJ2.Controls.Add(this.lblEnergia2);
			this.panelJ2.Controls.Add(this.barEnergia2);
			this.panelJ2.Controls.Add(this.lblEspecial2);
			this.panelJ2.Controls.Add(this.barEspecial2);
			this.Controls.Add(this.lblEscenario);
			this.Controls.Add(this.lblReloj);
			this.Controls.Add(this.panelJ1);
			this.Controls.Add(this.panelJ2);
			this.panelMovimiento.Controls.Add(this.lblMovimientoTitulo);
			this.panelMovimiento.Controls.Add(this.lblMovimiento);
			this.Controls.Add(this.panelMovimiento);
			this.Controls.Add(this.lblBitacora);
			this.Controls.Add(this.lstBitacora);
			this.Controls.Add(this.chkRelevar);
			this.Controls.Add(this.chkDefender);
			this.Controls.Add(this.chkHabilidad);
			this.Controls.Add(this.chkAtacar);
			this.Controls.Add(this.btnEjecutar);
			this.Controls.Add(this.lblTurno);
			this.Controls.Add(this.lblBanca1);
			this.Controls.Add(this.lstBanca1);
			this.Controls.Add(this.lblBanca2);
			this.Controls.Add(this.lstBanca2);
			this.Controls.Add(this.btnVolver);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FormBatalla";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Batalla";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormBatallaFormClosed);
			this.panelJ1.ResumeLayout(false);
			this.panelJ2.ResumeLayout(false);
			this.panelMovimiento.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblEscenario;
		private System.Windows.Forms.Label lblReloj;
		private System.Windows.Forms.Panel panelJ1;
		private System.Windows.Forms.Label lblJugador1;
		private System.Windows.Forms.PictureBox picJ1;
		private System.Windows.Forms.Label lblNombreJ1;
		private System.Windows.Forms.Label lblVida1;
		private System.Windows.Forms.ProgressBar barVida1;
		private System.Windows.Forms.Label lblEscudo1;
		private System.Windows.Forms.ProgressBar barEscudo1;
		private System.Windows.Forms.Label lblEnergia1;
		private System.Windows.Forms.ProgressBar barEnergia1;
		private System.Windows.Forms.Label lblEspecial1;
		private System.Windows.Forms.ProgressBar barEspecial1;
		private System.Windows.Forms.Panel panelJ2;
		private System.Windows.Forms.Label lblJugador2;
		private System.Windows.Forms.PictureBox picJ2;
		private System.Windows.Forms.Label lblNombreJ2;
		private System.Windows.Forms.Label lblVida2;
		private System.Windows.Forms.ProgressBar barVida2;
		private System.Windows.Forms.Label lblEscudo2;
		private System.Windows.Forms.ProgressBar barEscudo2;
		private System.Windows.Forms.Label lblEnergia2;
		private System.Windows.Forms.ProgressBar barEnergia2;
		private System.Windows.Forms.Label lblEspecial2;
		private System.Windows.Forms.ProgressBar barEspecial2;
		private System.Windows.Forms.Panel panelMovimiento;
		private System.Windows.Forms.Label lblMovimientoTitulo;
		private System.Windows.Forms.Label lblMovimiento;
		private System.Windows.Forms.Label lblBitacora;
		private System.Windows.Forms.ListBox lstBitacora;
		private System.Windows.Forms.CheckBox chkRelevar;
		private System.Windows.Forms.CheckBox chkDefender;
		private System.Windows.Forms.CheckBox chkHabilidad;
		private System.Windows.Forms.CheckBox chkAtacar;
		private System.Windows.Forms.Button btnEjecutar;
		private System.Windows.Forms.Label lblTurno;
		private System.Windows.Forms.Label lblBanca1;
		private System.Windows.Forms.ListBox lstBanca1;
		private System.Windows.Forms.Label lblBanca2;
		private System.Windows.Forms.ListBox lstBanca2;
		private System.Windows.Forms.Button btnVolver;
	}
}
