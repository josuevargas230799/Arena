﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ArenaElemental
{
	//tablero de batalla
	public partial class FormBatalla : Form
	{
		//modos de juego
		public const int MODO_LOCAL = 0;
		public const int MODO_MAQUINA = 1;
		public const int MODO_RED = 2;

		Form anterior;
		Partida partida;
		int modo;
		int local;              //jugador de esta computadora (solo en red)
		Red red;
		PerfilJugador[] perfiles;

		Timer timerTurno;       //reloj del turno (1 segundo)
		Timer timerRed;         //revisa los mensajes de la red
		int tiempo;
		bool finalizada = false;

		//pausa para leer el ultimo movimiento antes de pasar al otro jugador
		const int SEGUNDOS_PAUSA = 3;
		int pausa = 0;
		string fondoActual = "";

		public FormBatalla()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_fuego.png");
			lblMovimientoTitulo.ForeColor = Color.FromArgb(240, 200, 120);
		}

		public FormBatalla(Form config, Partida p, int modo, int local, Red red, PerfilJugador[] perfiles) : this()
		{
			anterior = config;
			partida = p;
			this.modo = modo;
			this.local = local;
			this.red = red;
			this.perfiles = perfiles;

			//timers
			timerTurno = new Timer();
			timerTurno.Interval = 1000;
			timerTurno.Tick += new EventHandler(TimerTurnoTick);

			timerRed = new Timer();
			timerRed.Interval = 250;
			timerRed.Tick += new EventHandler(TimerRedTick);

			Actualizar();
			NuevoTurno();

			//mensaje inicial en el cuadro de ultimo movimiento
			lblMovimientoTitulo.Text = "Último movimiento";
			lblMovimiento.Text = "¡Comienza la batalla!\nEmpieza " + partida.Actual.Nombre + ".";

			timerTurno.Start();
			timerRed.Start();
		}

		//----- turnos -----

		//de quien es el control en esta computadora
		bool EsTurnoLocal()
		{
			if (modo == MODO_LOCAL) return true;
			if (modo == MODO_MAQUINA) return partida.Actual.Numero == 1;
			return partida.Actual.Numero == local;
		}

		//preparar la pantalla para un turno nuevo
		void NuevoTurno()
		{
			tiempo = Configuracion.TiempoTurno;

			chkRelevar.Checked = false;
			chkDefender.Checked = false;
			chkHabilidad.Checked = false;
			chkAtacar.Checked = false;

			HabilitarControles(EsTurnoLocal());

			Jugador a = partida.Actual;
			string texto = "Turno " + partida.Turno + " - " + a.Nombre + "\nEnergía: " + a.Energia + "/" + a.Activo.EnergiaMax;
			if (EsTurnoLocal())
			{
				texto = texto + "\nMarca tus acciones y pulsa Ejecutar";
			}
			else
			{
				texto = texto + "\nEsperando al rival...";
			}
			lblTurno.Text = texto;
			MostrarReloj();
		}

		//activar o desactivar los botones de accion
		void HabilitarControles(bool activar)
		{
			chkRelevar.Enabled = activar;
			chkDefender.Enabled = activar;
			chkAtacar.Enabled = activar;
			btnEjecutar.Enabled = activar;

			//la habilidad solo se puede usar si esta cargada
			chkHabilidad.Enabled = activar && partida.Actual.Activo.HabilidadLista;
		}

		void MostrarReloj()
		{
			int segundos = tiempo;
			if (segundos < 0) segundos = 0;
			lblReloj.Text = "Tiempo: 00:" + segundos.ToString("00");
		}

		//ejecutar lo que el jugador marco
		void EjecutarSeleccion()
		{
			bool relevar = chkRelevar.Checked;
			bool defender = chkDefender.Checked;
			bool habilidad = chkHabilidad.Checked;
			bool atacar = chkAtacar.Checked;

			partida.EjecutarTurno(relevar, defender, habilidad, atacar);

			//avisar al rival en modo red
			if (modo == MODO_RED)
			{
				try
				{
					red.Enviar("TURNO|" + Bit(relevar) + "|" + Bit(defender) + "|" + Bit(habilidad) + "|" + Bit(atacar));
				}
				catch (Exception)
				{
					ConexionPerdida();
					return;
				}
			}

			TrasTurno();
		}

		//despues de cada turno: se muestra lo que paso y se espera 3 segundos
		void TrasTurno()
		{
			Actualizar();
			MostrarMovimiento();

			HabilitarControles(false);
			lblReloj.Text = "Tiempo: --";
			pausa = SEGUNDOS_PAUSA;

			if (partida.Terminada)
			{
				lblTurno.Text = "Fin de la partida...";
			}
			else
			{
				lblTurno.Text = "Siguiente turno en " + pausa + "...";
			}
		}

		//cuando termina la pausa de 3 segundos
		void TerminarPausa()
		{
			if (partida.Terminada)
			{
				Finalizar();
			}
			else
			{
				NuevoTurno();
			}
		}

		//mostrar lo que paso en el ultimo turno
		void MostrarMovimiento()
		{
			lblMovimientoTitulo.Text = "Último movimiento de " + partida.UltimoJugador;

			string texto = "";
			foreach (string linea in partida.UltimoResumen)
			{
				if (texto != "") texto = texto + "\n";
				texto = texto + linea;
			}
			lblMovimiento.Text = texto;
		}

		//poner la imagen de fondo del escenario actual
		void CambiarFondo()
		{
			string archivo = partida.EscenarioActual.Fondo;
			if (archivo == fondoActual) return;

			Image img = Estilo.CargarImagen(archivo);
			if (img != null)
			{
				BackgroundImage = img;
				BackgroundImageLayout = ImageLayout.Stretch;
			}
			fondoActual = archivo;
		}

		string Bit(bool valor)
		{
			if (valor) return "1";
			return "0";
		}

		//----- timers -----

		//cada segundo
		void TimerTurnoTick(object sender, EventArgs e)
		{
			if (finalizada) return;

			//pausa para leer el ultimo movimiento
			if (pausa > 0)
			{
				pausa--;
				if (pausa == 0)
				{
					TerminarPausa();
				}
				else if (!partida.Terminada)
				{
					lblTurno.Text = "Siguiente turno en " + pausa + "...";
				}
				return;
			}

			//la maquina juega en su turno
			if (modo == MODO_MAQUINA && partida.Actual.Numero == 2)
			{
				bool[] a = Maquina.Decidir(partida);
				partida.EjecutarTurno(a[0], a[1], a[2], a[3]);
				TrasTurno();
				return;
			}

			tiempo--;
			MostrarReloj();

			//si se acaba el tiempo se ejecuta lo que se alcanzo a marcar
			if (tiempo <= 0 && EsTurnoLocal())
			{
				EjecutarSeleccion();
			}
		}

		//revisar mensajes del rival
		void TimerRedTick(object sender, EventArgs e)
		{
			if (modo != MODO_RED || finalizada) return;

			try
			{
				string linea = red.Leer();
				while (linea != null && !finalizada)
				{
					ProcesarMensaje(linea);
					linea = red.Leer();
				}

				if (!finalizada && red.Desconectado())
				{
					ConexionPerdida();
				}
			}
			catch (Exception)
			{
				ConexionPerdida();
			}
		}

		//interpretar un mensaje de la red
		void ProcesarMensaje(string linea)
		{
			string[] partes = linea.Split('|');

			if (partes[0] == "TURNO" && partes.Length >= 5 && !EsTurnoLocal())
			{
				partida.EjecutarTurno(partes[1] == "1", partes[2] == "1", partes[3] == "1", partes[4] == "1");
				TrasTurno();
			}
			else if (partes[0] == "ABANDONO")
			{
				partida.TerminarPorAbandono(JugadorLocal());
				TrasTurno();
			}
		}

		Jugador JugadorLocal()
		{
			if (local == 1) return partida.Jugador1;
			return partida.Jugador2;
		}

		void ConexionPerdida()
		{
			if (finalizada) return;

			timerRed.Stop();
			timerTurno.Stop();
			MessageBox.Show("Se perdió la conexión con el rival.");

			partida.TerminarPorAbandono(JugadorLocal());
			Actualizar();
			MostrarMovimiento();
			Finalizar();
		}

		//----- pantalla -----

		//refrescar todo lo que se ve
		void Actualizar()
		{
			CambiarFondo();

			MostrarJugador(partida.Jugador1, picJ1, lblNombreJ1, lblVida1, barVida1, lblEscudo1, barEscudo1,
				lblEnergia1, barEnergia1, lblEspecial1, barEspecial1, lstBanca1);
			MostrarJugador(partida.Jugador2, picJ2, lblNombreJ2, lblVida2, barVida2, lblEscudo2, barEscudo2,
				lblEnergia2, barEnergia2, lblEspecial2, barEspecial2, lstBanca2);

			//nombres y marca del turno
			lblJugador1.Text = partida.Jugador1.Nombre;
			lblJugador2.Text = partida.Jugador2.Nombre;
			if (!partida.Terminada)
			{
				if (partida.Actual == partida.Jugador1) lblJugador1.Text = "> " + lblJugador1.Text + " <";
				else lblJugador2.Text = "> " + lblJugador2.Text + " <";
			}

			lblBanca1.Text = "Banca de " + partida.Jugador1.Nombre + " (" + partida.Jugador1.PersonajesRestantes + " vivos)";
			lblBanca2.Text = "Banca de " + partida.Jugador2.Nombre + " (" + partida.Jugador2.PersonajesRestantes + " vivos)";

			lblEscenario.Text = "Escenario: " + partida.EscenarioActual.Nombre + " (" + partida.EscenarioActual.Elemento + ")";

			//la bitacora muestra la pila: lo mas reciente arriba
			lstBitacora.Items.Clear();
			foreach (string linea in partida.Historial)
			{
				lstBitacora.Items.Add(linea);
			}
		}

		//mostrar un jugador
		void MostrarJugador(Jugador j, PictureBox pic, Label lblNombre, Label lblVida, ProgressBar barVida,
		                    Label lblEscudo, ProgressBar barEscudo, Label lblEnergia, ProgressBar barEnergia,
		                    Label lblEspecial, ProgressBar barEspecial, ListBox banca)
		{
			Personaje p = j.Activo;

			pic.Image = Estilo.CargarImagen(p.Nombre + ".png");
			lblNombre.Text = p.Nombre + " (" + p.Elemento + ")";

			//vida
			barVida.Maximum = p.VidaMax;
			barVida.Value = p.Vida;
			lblVida.Text = "Vida " + p.Vida + "/" + p.VidaMax;

			//escudo
			barEscudo.Maximum = p.EscudoMax;
			barEscudo.Value = p.Escudo;
			lblEscudo.Text = "Escudo " + p.Escudo;

			//energia
			barEnergia.Maximum = p.EnergiaMax;
			barEnergia.Value = Math.Min(j.Energia, p.EnergiaMax);
			lblEnergia.Text = "Energía " + j.Energia;

			//habilidad especial
			barEspecial.Maximum = 100;
			barEspecial.Value = p.Carga;
			lblEspecial.Text = "Especial " + p.Carga + "%";

			//cola de relevos
			banca.Items.Clear();
			foreach (Personaje x in j.Banca)
			{
				banca.Items.Add(x.Nombre + " - " + x.Elemento + " (Vida " + x.Vida + "/" + x.VidaMax + ")");
			}
		}

		//----- fin de la partida -----

		void Finalizar()
		{
			finalizada = true;
			timerTurno.Stop();
			timerRed.Stop();
			HabilitarControles(false);

			//archivo .txt de la bitacora y estadisticas
			string modoTexto = "Local";
			if (modo == MODO_MAQUINA) modoTexto = "Contra máquina";
			if (modo == MODO_RED) modoTexto = "Red";

			string archivo = RegistroBatalla.Guardar(partida, modoTexto);
			GuardarEstadisticas(archivo);

			lblTurno.Text = "Fin de la partida\nGana " + partida.Ganador.Nombre;
			MessageBox.Show("Fin de la partida. Gana " + partida.Ganador.Nombre + ".\nBitácora: " + archivo);
		}

		//actualizar las estadisticas de los jugadores que tienen cuenta
		void GuardarEstadisticas(string archivo)
		{
			for (int n = 1; n <= 2; n++)
			{
				PerfilJugador perfil = perfiles[n];
				if (perfil == null || perfil.Id == 0) continue;

				Jugador yo = partida.Jugador1;
				Jugador rival = partida.Jugador2;
				if (n == 2)
				{
					yo = partida.Jugador2;
					rival = partida.Jugador1;
				}

				bool victoria = (partida.Ganador == yo);
				string error = Almacen.RegistrarResultado(perfil.Id, rival.Nombre, victoria, partida.Turno, archivo);
				if (error != "")
				{
					MessageBox.Show("No se pudieron guardar las estadísticas de " + perfil.Nombre + ": " + error);
				}
			}
		}

		//----- botones -----

		//boton ejecutar turno
		void BtnEjecutarClick(object sender, EventArgs e)
		{
			EjecutarSeleccion();
		}

		//boton volver
		void BtnVolverClick(object sender, EventArgs e)
		{
			Close();
		}

		//al cerrar se muestra la configuracion
		void FormBatallaFormClosed(object sender, FormClosedEventArgs e)
		{
			if (timerTurno != null) timerTurno.Stop();
			if (timerRed != null) timerRed.Stop();

			//en red se avisa al rival si la partida no habia terminado
			if (modo == MODO_RED && red != null)
			{
				if (!finalizada)
				{
					try
					{
						red.Enviar("ABANDONO");
					}
					catch (Exception)
					{
						//si falla el rival ya se desconecto
					}
				}
				red.Cerrar();
			}

			if (anterior != null) anterior.Show();
		}
	}
}
