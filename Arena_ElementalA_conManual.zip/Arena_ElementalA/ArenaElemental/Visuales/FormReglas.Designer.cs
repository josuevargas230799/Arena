﻿/*
 * Archivo del Designer de FormReglas
 */
namespace ArenaElemental
{
	partial class FormReglas
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.txtReglas = new System.Windows.Forms.TextBox();
			this.btnVolver = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btnAbrir = new System.Windows.Forms.Button();
			this.btnDescargar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.Location = new System.Drawing.Point(20, 10);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Size = new System.Drawing.Size(300, 45);
			this.lblTitulo.TabIndex = 0;
			this.lblTitulo.Text = "Reglas";
			// 
			// txtReglas
			// 
			this.txtReglas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(228)))));
			this.txtReglas.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtReglas.Location = new System.Drawing.Point(20, 103);
			this.txtReglas.Multiline = true;
			this.txtReglas.Name = "txtReglas";
			this.txtReglas.ReadOnly = true;
			this.txtReglas.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtReglas.Size = new System.Drawing.Size(960, 422);
			this.txtReglas.TabIndex = 1;
			// 
			// btnVolver
			// 
			this.btnVolver.Location = new System.Drawing.Point(20, 540);
			this.btnVolver.Name = "btnVolver";
			this.btnVolver.Size = new System.Drawing.Size(130, 40);
			this.btnVolver.TabIndex = 2;
			this.btnVolver.Text = "Volver";
			this.btnVolver.Click += new System.EventHandler(this.BtnVolverClick);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(545, 14);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(267, 37);
			this.label3.TabIndex = 13;
			this.label3.Text = "Descargar manual desde la wed";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(212, 14);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(171, 23);
			this.label1.TabIndex = 12;
			this.label1.Text = "Manual de Usuario";
			// 
			// btnAbrir
			// 
			this.btnAbrir.Location = new System.Drawing.Point(249, 49);
			this.btnAbrir.Name = "btnAbrir";
			this.btnAbrir.Size = new System.Drawing.Size(90, 39);
			this.btnAbrir.TabIndex = 11;
			this.btnAbrir.Text = "Abrir";
			this.btnAbrir.UseVisualStyleBackColor = true;
			this.btnAbrir.Click += new System.EventHandler(this.BtnAbrirClick);
			// 
			// btnDescargar
			// 
			this.btnDescargar.Location = new System.Drawing.Point(611, 49);
			this.btnDescargar.Name = "btnDescargar";
			this.btnDescargar.Size = new System.Drawing.Size(90, 39);
			this.btnDescargar.TabIndex = 14;
			this.btnDescargar.Text = "Descargar";
			this.btnDescargar.UseVisualStyleBackColor = true;
			this.btnDescargar.Click += new System.EventHandler(this.BtnDescargarClick);
			// 
			// FormReglas
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.Controls.Add(this.btnDescargar);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnAbrir);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.txtReglas);
			this.Controls.Add(this.btnVolver);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FormReglas";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Reglas";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormReglasFormClosed);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.TextBox txtReglas;
		private System.Windows.Forms.Button btnVolver;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnAbrir;
		private System.Windows.Forms.Button btnDescargar;
	}
}
