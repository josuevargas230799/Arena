﻿/*
 * Archivo del Designer de FormLogin
 */
namespace ArenaElemental
{
	partial class FormLogin
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.lblUsuario = new System.Windows.Forms.Label();
			this.txtUsuario = new System.Windows.Forms.TextBox();
			this.lblClave = new System.Windows.Forms.Label();
			this.txtClave = new System.Windows.Forms.TextBox();
			this.btnEntrar = new System.Windows.Forms.Button();
			this.btnRegistrar = new System.Windows.Forms.Button();
			this.btnInvitado = new System.Windows.Forms.Button();
			this.btnCancelar = new System.Windows.Forms.Button();
			this.lblMensaje = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.AutoSize = false;
			this.lblTitulo.Location = new System.Drawing.Point(20, 15);
			this.lblTitulo.Size = new System.Drawing.Size(420, 50);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Text = "Iniciar sesión";
			this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblUsuario
			// 
			this.lblUsuario.AutoSize = false;
			this.lblUsuario.Location = new System.Drawing.Point(40, 90);
			this.lblUsuario.Size = new System.Drawing.Size(120, 28);
			this.lblUsuario.Name = "lblUsuario";
			this.lblUsuario.Text = "Usuario";
			// 
			// txtUsuario
			// 
			this.txtUsuario.Location = new System.Drawing.Point(170, 88);
			this.txtUsuario.Size = new System.Drawing.Size(240, 28);
			this.txtUsuario.Name = "txtUsuario";
			// 
			// lblClave
			// 
			this.lblClave.AutoSize = false;
			this.lblClave.Location = new System.Drawing.Point(40, 135);
			this.lblClave.Size = new System.Drawing.Size(120, 28);
			this.lblClave.Name = "lblClave";
			this.lblClave.Text = "Clave";
			// 
			// txtClave
			// 
			this.txtClave.Location = new System.Drawing.Point(170, 133);
			this.txtClave.Size = new System.Drawing.Size(240, 28);
			this.txtClave.Name = "txtClave";
			this.txtClave.UseSystemPasswordChar = true;
			// 
			// btnEntrar
			// 
			this.btnEntrar.Location = new System.Drawing.Point(40, 190);
			this.btnEntrar.Size = new System.Drawing.Size(180, 40);
			this.btnEntrar.Name = "btnEntrar";
			this.btnEntrar.Text = "Entrar";
			this.btnEntrar.Click += new System.EventHandler(this.BtnEntrarClick);
			// 
			// btnRegistrar
			// 
			this.btnRegistrar.Location = new System.Drawing.Point(240, 190);
			this.btnRegistrar.Size = new System.Drawing.Size(180, 40);
			this.btnRegistrar.Name = "btnRegistrar";
			this.btnRegistrar.Text = "Registrar";
			this.btnRegistrar.Click += new System.EventHandler(this.BtnRegistrarClick);
			// 
			// btnInvitado
			// 
			this.btnInvitado.Location = new System.Drawing.Point(40, 240);
			this.btnInvitado.Size = new System.Drawing.Size(180, 40);
			this.btnInvitado.Name = "btnInvitado";
			this.btnInvitado.Text = "Invitado";
			this.btnInvitado.Click += new System.EventHandler(this.BtnInvitadoClick);
			// 
			// btnCancelar
			// 
			this.btnCancelar.Location = new System.Drawing.Point(240, 240);
			this.btnCancelar.Size = new System.Drawing.Size(180, 40);
			this.btnCancelar.Name = "btnCancelar";
			this.btnCancelar.Text = "Cancelar";
			this.btnCancelar.Click += new System.EventHandler(this.BtnCancelarClick);
			// 
			// lblMensaje
			// 
			this.lblMensaje.AutoSize = false;
			this.lblMensaje.Location = new System.Drawing.Point(40, 295);
			this.lblMensaje.Size = new System.Drawing.Size(380, 50);
			this.lblMensaje.Name = "lblMensaje";
			this.lblMensaje.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// FormLogin
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(460, 360);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.lblUsuario);
			this.Controls.Add(this.txtUsuario);
			this.Controls.Add(this.lblClave);
			this.Controls.Add(this.txtClave);
			this.Controls.Add(this.btnEntrar);
			this.Controls.Add(this.btnRegistrar);
			this.Controls.Add(this.btnInvitado);
			this.Controls.Add(this.btnCancelar);
			this.Controls.Add(this.lblMensaje);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.Name = "FormLogin";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Iniciar sesión";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Label lblUsuario;
		private System.Windows.Forms.TextBox txtUsuario;
		private System.Windows.Forms.Label lblClave;
		private System.Windows.Forms.TextBox txtClave;
		private System.Windows.Forms.Button btnEntrar;
		private System.Windows.Forms.Button btnRegistrar;
		private System.Windows.Forms.Button btnInvitado;
		private System.Windows.Forms.Button btnCancelar;
		private System.Windows.Forms.Label lblMensaje;
	}
}
