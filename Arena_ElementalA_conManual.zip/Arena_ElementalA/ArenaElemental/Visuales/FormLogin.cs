﻿using System;
using System.Windows.Forms;

namespace ArenaElemental
{
	//ventana para iniciar sesion o registrarse
	public partial class FormLogin : Form
	{
		int numeroJugador = 1;

		//resultado del login
		public PerfilJugador Perfil = null;

		public FormLogin()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_juego.png");
		}

		public FormLogin(int numero) : this()
		{
			numeroJugador = numero;
			lblTitulo.Text = "Jugador " + numero;
		}

		//boton entrar
		void BtnEntrarClick(object sender, EventArgs e)
		{
			string usuario = txtUsuario.Text.Trim();
			if (usuario == "" || txtClave.Text == "")
			{
				lblMensaje.Text = "Escribe el usuario y la clave";
				return;
			}

			PerfilJugador p = Almacen.Login(usuario, txtClave.Text);
			if (p != null)
			{
				Perfil = p;
				DialogResult = DialogResult.OK;
			}
			else if (Almacen.UltimoError != "")
			{
				lblMensaje.Text = "No se pudo leer el archivo de jugadores. Puedes entrar como invitado.";
			}
			else
			{
				lblMensaje.Text = "Usuario o clave incorrectos";
			}
		}

		//boton registrar
		void BtnRegistrarClick(object sender, EventArgs e)
		{
			string usuario = txtUsuario.Text.Trim();
			if (usuario.Length < 3 || txtClave.Text.Length < 3)
			{
				lblMensaje.Text = "El usuario y la clave deben tener al menos 3 caracteres";
				return;
			}

			string error = Almacen.Registrar(usuario, txtClave.Text);
			if (error == "")
			{
				lblMensaje.Text = "Cuenta creada. Ahora pulsa Entrar.";
			}
			else
			{
				lblMensaje.Text = error;
			}
		}

		//boton invitado (no guarda estadisticas)
		void BtnInvitadoClick(object sender, EventArgs e)
		{
			Perfil = new PerfilJugador();
			Perfil.Id = 0;
			Perfil.Nombre = "Invitado " + numeroJugador;
			DialogResult = DialogResult.OK;
		}

		//boton cancelar
		void BtnCancelarClick(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}
	}
}
