﻿/*
 * Archivo del Designer de FormConexion
 */
namespace ArenaElemental
{
	partial class FormConexion
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.lblEstado = new System.Windows.Forms.Label();
			this.lblInfo = new System.Windows.Forms.Label();
			this.btnCancelar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.AutoSize = false;
			this.lblTitulo.Location = new System.Drawing.Point(20, 10);
			this.lblTitulo.Size = new System.Drawing.Size(420, 45);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Text = "Conexión en red";
			this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblEstado
			// 
			this.lblEstado.AutoSize = false;
			this.lblEstado.Location = new System.Drawing.Point(20, 70);
			this.lblEstado.Size = new System.Drawing.Size(420, 50);
			this.lblEstado.Name = "lblEstado";
			this.lblEstado.Text = "Conectando...";
			this.lblEstado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblInfo
			// 
			this.lblInfo.AutoSize = false;
			this.lblInfo.Location = new System.Drawing.Point(20, 120);
			this.lblInfo.Size = new System.Drawing.Size(420, 30);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnCancelar
			// 
			this.btnCancelar.Location = new System.Drawing.Point(165, 165);
			this.btnCancelar.Size = new System.Drawing.Size(130, 40);
			this.btnCancelar.Name = "btnCancelar";
			this.btnCancelar.Text = "Cancelar";
			this.btnCancelar.Click += new System.EventHandler(this.BtnCancelarClick);
			// 
			// FormConexion
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(460, 220);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.lblEstado);
			this.Controls.Add(this.lblInfo);
			this.Controls.Add(this.btnCancelar);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.Name = "FormConexion";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Conexión en red";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormConexionFormClosed);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Label lblEstado;
		private System.Windows.Forms.Label lblInfo;
		private System.Windows.Forms.Button btnCancelar;
	}
}
