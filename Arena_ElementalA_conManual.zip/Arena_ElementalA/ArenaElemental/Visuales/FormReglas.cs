﻿using System;
using System.Windows.Forms;

namespace ArenaElemental
{
	public partial class FormReglas : Form
	{
		Form anterior;

		public FormReglas()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_juego.png");

			//texto de las reglas
			txtReglas.Text =
				"OBJETIVO\r\n" +
				"Deja sin vida a los 5 personajes del equipo rival.\r\n\r\n" +
				"EQUIPOS\r\n" +
				"Cada jugador arma un equipo de 5 personajes. El primero es el activo y los demás esperan en la cola de relevos.\r\n\r\n" +
				"TURNOS Y ENERGÍA\r\n" +
				"Empieza un jugador al azar con 2 de energía. Después cada jugador gana 1 de energía al empezar su turno. " +
				"En cada turno marcas las acciones que quieres y pulsas Ejecutar turno. Si se acaba el tiempo se ejecutan las que alcanzaste a marcar. " +
				"Si no marcaste ninguna, el turno pasa.\r\n\r\n" +
				"ACCIONES\r\n" +
				"Atacar (1 de energía): el daño gasta primero el escudo y el resto baja la vida.\r\n" +
				"Defender (1): sube el escudo del personaje activo.\r\n" +
				"Habilidad especial (2): necesita estar cargada al 100%. Se carga 50% en cada turno propio.\r\n" +
				"Relevar (1): el activo pasa al final de la cola y entra el siguiente.\r\n\r\n" +
				"ELEMENTOS\r\n" +
				"Agua vence a Fuego, Fuego vence a Viento, Viento vence a Tierra y Tierra vence a Agua. La ventaja hace x1.5 de daño y la desventaja x0.75.\r\n\r\n" +
				"HABILIDADES\r\n" +
				"Fuego: impacto doble. Agua: curación. Tierra: golpe perforante. Viento: roba energía al rival.\r\n\r\n" +
				"ESCENARIOS Y TERREMOTO\r\n" +
				"El escenario mejora a los personajes de su elemento y penaliza al opuesto. Al final de cada ronda puede ocurrir un terremoto: " +
				"baja el escudo y la vida de los personajes activos (Tierra resiste la mitad). Si el personaje tiene empatía 7 o más, el terremoto lo cura.\r\n\r\n" +
				"FIN DE LA PARTIDA\r\n" +
				"Al terminar se guarda el resultado en el archivo de partidas y se crea un archivo .txt con la bitácora en la carpeta Logs.";
		}

		public FormReglas(Form menu) : this()
		{
			anterior = menu;
		}

		//boton volver
		void BtnVolverClick(object sender, EventArgs e)
		{
			Close();
		}

		//al cerrar se muestra el menu
		void FormReglasFormClosed(object sender, FormClosedEventArgs e)
		{
			if (anterior != null) anterior.Show();
		}
		void TextBox1TextChanged(object sender, EventArgs e)
		{
	
		}
		void BtnAbrirClick(object sender, EventArgs e)
		{
			Manual.AbrirManual();
		}
		void BtnDescargarClick(object sender, EventArgs e)
		{
			Manual.DescargarManual();
		}
	}
}
