﻿using System;
using System.Windows.Forms;

namespace ArenaElemental
{
	public partial class FormCartas : Form
	{
		Form anterior;

		public FormCartas()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_juego.png");
			CargarCartas();
		}

		public FormCartas(Form menu) : this()
		{
			anterior = menu;
		}

		//cartas
		void CargarCartas()
		{
			foreach (DatosCarta c in Catalogo.Obtener())
			{
				ListViewItem item = new ListViewItem(c.Nombre);
				item.SubItems.Add(c.Elemento);
				item.SubItems.Add(c.HP.ToString());
				item.SubItems.Add(c.DEF.ToString());
				item.SubItems.Add(c.ATK.ToString());
				item.SubItems.Add(c.ENER.ToString());
				item.SubItems.Add(c.EMP.ToString());
				item.SubItems.Add(c.Descripcion);
				item.Tag = c;
				lvCartas.Items.Add(item);
			}

			//seleccionar la primera
			if (lvCartas.Items.Count > 0)
			{
				lvCartas.Items[0].Selected = true;
			}
		}

		//carta seleccionada
		void LvCartasSelectedIndexChanged(object sender, EventArgs e)
		{
			if (lvCartas.SelectedItems.Count == 0) return;

			DatosCarta c = (DatosCarta)lvCartas.SelectedItems[0].Tag;
			picCarta.Image = Estilo.CargarImagen(c.Imagen);
			lblNombreCarta.Text = c.Nombre + " - " + c.Elemento;
			lblDetalle.Text = c.DescripcionDetallada + "\n\nTrasfondo: " + c.Trasfondo;
		}

		//boton volver
		void BtnVolverClick(object sender, EventArgs e)
		{
			Close();
		}

		//al cerrar se muestra el menu
		void FormCartasFormClosed(object sender, FormClosedEventArgs e)
		{
			if (anterior != null) anterior.Show();
		}
	}
}