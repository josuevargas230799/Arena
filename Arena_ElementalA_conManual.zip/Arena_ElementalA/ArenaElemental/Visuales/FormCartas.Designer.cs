﻿/*
 * Archivo del Designer de FormCartas
 */
namespace ArenaElemental
{
	partial class FormCartas
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.colNombre = new System.Windows.Forms.ColumnHeader();
			this.colElemento = new System.Windows.Forms.ColumnHeader();
			this.colHP = new System.Windows.Forms.ColumnHeader();
			this.colDEF = new System.Windows.Forms.ColumnHeader();
			this.colATK = new System.Windows.Forms.ColumnHeader();
			this.colENER = new System.Windows.Forms.ColumnHeader();
			this.colEMP = new System.Windows.Forms.ColumnHeader();
			this.colDescripcion = new System.Windows.Forms.ColumnHeader();
			this.lvCartas = new System.Windows.Forms.ListView();
			this.panelCarta = new System.Windows.Forms.Panel();
			this.picCarta = new System.Windows.Forms.PictureBox();
			this.lblNombreCarta = new System.Windows.Forms.Label();
			this.lblDetalle = new System.Windows.Forms.Label();
			this.btnVolver = new System.Windows.Forms.Button();
			this.panelCarta.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.AutoSize = false;
			this.lblTitulo.Location = new System.Drawing.Point(20, 10);
			this.lblTitulo.Size = new System.Drawing.Size(300, 45);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Text = "Cartas";
			this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// colNombre
			// 
			this.colNombre.Text = "Nombre";
			this.colNombre.Width = 85;
			// 
			// colElemento
			// 
			this.colElemento.Text = "Elemento";
			this.colElemento.Width = 70;
			// 
			// colHP
			// 
			this.colHP.Text = "HP";
			this.colHP.Width = 35;
			// 
			// colDEF
			// 
			this.colDEF.Text = "DEF";
			this.colDEF.Width = 40;
			// 
			// colATK
			// 
			this.colATK.Text = "ATK";
			this.colATK.Width = 40;
			// 
			// colENER
			// 
			this.colENER.Text = "ENER";
			this.colENER.Width = 45;
			// 
			// colEMP
			// 
			this.colEMP.Text = "EMP";
			this.colEMP.Width = 40;
			// 
			// colDescripcion
			// 
			this.colDescripcion.Text = "Descripción";
			this.colDescripcion.Width = 240;
			// 
			// lvCartas
			// 
			this.lvCartas.Location = new System.Drawing.Point(20, 65);
			this.lvCartas.Size = new System.Drawing.Size(620, 460);
			this.lvCartas.Name = "lvCartas";
			this.lvCartas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
						this.colNombre,
						this.colElemento,
						this.colHP,
						this.colDEF,
						this.colATK,
						this.colENER,
						this.colEMP,
						this.colDescripcion});
			this.lvCartas.FullRowSelect = true;
			this.lvCartas.HideSelection = false;
			this.lvCartas.MultiSelect = false;
			this.lvCartas.UseCompatibleStateImageBehavior = false;
			this.lvCartas.View = System.Windows.Forms.View.Details;
			this.lvCartas.BackColor = System.Drawing.Color.FromArgb(235, 235, 228);
			this.lvCartas.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lvCartas.SelectedIndexChanged += new System.EventHandler(this.LvCartasSelectedIndexChanged);
			// 
			// panelCarta
			// 
			this.panelCarta.Location = new System.Drawing.Point(660, 65);
			this.panelCarta.Size = new System.Drawing.Size(320, 460);
			this.panelCarta.Name = "panelCarta";
			this.panelCarta.BackColor = System.Drawing.Color.FromArgb(30, 35, 60);
			// 
			// picCarta
			// 
			this.picCarta.Location = new System.Drawing.Point(90, 10);
			this.picCarta.Size = new System.Drawing.Size(140, 200);
			this.picCarta.Name = "picCarta";
			this.picCarta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			// 
			// lblNombreCarta
			// 
			this.lblNombreCarta.AutoSize = false;
			this.lblNombreCarta.Location = new System.Drawing.Point(10, 215);
			this.lblNombreCarta.Size = new System.Drawing.Size(300, 30);
			this.lblNombreCarta.Name = "lblNombreCarta";
			this.lblNombreCarta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblDetalle
			// 
			this.lblDetalle.AutoSize = false;
			this.lblDetalle.Location = new System.Drawing.Point(10, 250);
			this.lblDetalle.Size = new System.Drawing.Size(300, 200);
			this.lblDetalle.Name = "lblDetalle";
			this.lblDetalle.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			// 
			// btnVolver
			// 
			this.btnVolver.Location = new System.Drawing.Point(20, 540);
			this.btnVolver.Size = new System.Drawing.Size(130, 40);
			this.btnVolver.Name = "btnVolver";
			this.btnVolver.Text = "Volver";
			this.btnVolver.Click += new System.EventHandler(this.BtnVolverClick);
			// 
			// FormCartas
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.panelCarta.Controls.Add(this.picCarta);
			this.panelCarta.Controls.Add(this.lblNombreCarta);
			this.panelCarta.Controls.Add(this.lblDetalle);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.lvCartas);
			this.Controls.Add(this.panelCarta);
			this.Controls.Add(this.btnVolver);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FormCartas";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Cartas";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormCartasFormClosed);
			this.panelCarta.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.ColumnHeader colNombre;
		private System.Windows.Forms.ColumnHeader colElemento;
		private System.Windows.Forms.ColumnHeader colHP;
		private System.Windows.Forms.ColumnHeader colDEF;
		private System.Windows.Forms.ColumnHeader colATK;
		private System.Windows.Forms.ColumnHeader colENER;
		private System.Windows.Forms.ColumnHeader colEMP;
		private System.Windows.Forms.ColumnHeader colDescripcion;
		private System.Windows.Forms.ListView lvCartas;
		private System.Windows.Forms.Panel panelCarta;
		private System.Windows.Forms.PictureBox picCarta;
		private System.Windows.Forms.Label lblNombreCarta;
		private System.Windows.Forms.Label lblDetalle;
		private System.Windows.Forms.Button btnVolver;
	}
}