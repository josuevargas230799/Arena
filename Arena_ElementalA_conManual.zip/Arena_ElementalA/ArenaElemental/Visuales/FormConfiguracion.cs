﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ArenaElemental
{
	//configuracion previa a la batalla
	public partial class FormConfiguracion : Form
	{
		Form anterior;

		//todas las cartas y el equipo de cada jugador
		List<DatosCarta> catalogo = Catalogo.Obtener();
		Dictionary<string, List<DatosCarta>> equipos = new Dictionary<string, List<DatosCarta>>();

		//sesion de cada jugador (posiciones 1 y 2)
		PerfilJugador[] perfiles = new PerfilJugador[3];

		public FormConfiguracion()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_config.png");

			//equipos
			equipos["Jugador 1"] = new List<DatosCarta>();
			equipos["Jugador 2"] = new List<DatosCarta>();

			//valores iniciales de los combos
			cmbModo.SelectedIndex = 0;
			cmbJugador.SelectedIndex = 0;
			cmbTipo.SelectedIndex = 0;
		}

		public FormConfiguracion(Form menu) : this()
		{
			anterior = menu;
		}

		//cartas disponibles segun el tipo
		void CargarDisponibles()
		{
			lstDisponibles.Items.Clear();
			foreach (DatosCarta c in catalogo)
			{
				if (cmbTipo.Text == "Todos" || c.Elemento == cmbTipo.Text)
				{
					lstDisponibles.Items.Add(c);
				}
			}
		}

		//cartas seleccionadas del jugador actual
		void CargarSeleccionadas()
		{
			lstSeleccionadas.Items.Clear();
			List<DatosCarta> equipo = equipos[cmbJugador.Text];
			foreach (DatosCarta c in equipo)
			{
				lstSeleccionadas.Items.Add(c);
			}
			lblConteo.Text = "Cartas: " + equipo.Count + "/" + Configuracion.MAX_EQUIPO;
		}

		//texto de la sesion
		void ActualizarSesion()
		{
			int n = cmbJugador.SelectedIndex + 1;
			if (perfiles[n] == null)
			{
				lblSesion.Text = "Sesión: ninguna";
			}
			else
			{
				lblSesion.Text = "Sesión: " + perfiles[n].Nombre;
			}
		}

		//vista previa y descripcion
		void MostrarPrevia(ListBox lista)
		{
			DatosCarta c = lista.SelectedItem as DatosCarta;
			if (c == null) return;

			picPrevia.Image = Estilo.CargarImagen(c.Imagen);
			lblDescripcion.Text = c.Nombre + " (" + c.Elemento + ")\n" + c.Descripcion;
		}

		//buscar una carta en un equipo por su Id
		bool EstaEnEquipo(List<DatosCarta> equipo, DatosCarta carta)
		{
			foreach (DatosCarta c in equipo)
			{
				if (c.Id == carta.Id) return true;
			}
			return false;
		}

		//combo tipo
		void CmbTipoSelectedIndexChanged(object sender, EventArgs e)
		{
			CargarDisponibles();
		}

		//combo modo
		void CmbModoSelectedIndexChanged(object sender, EventArgs e)
		{
			int modo = cmbModo.SelectedIndex;

			//el puerto se usa en red y la IP solo en el cliente
			lblPuerto.Visible = (modo >= 2);
			txtPuerto.Visible = (modo >= 2);
			lblIp.Visible = (modo == 3);
			txtIp.Visible = (modo == 3);

			//en red solo se juega con el Jugador 1 de esta computadora
			if (modo >= 2)
			{
				cmbJugador.SelectedIndex = 0;
				cmbJugador.Enabled = false;
			}
			else
			{
				cmbJugador.Enabled = true;
			}
		}

		//combo jugador
		void CmbJugadorSelectedIndexChanged(object sender, EventArgs e)
		{
			CargarSeleccionadas();
			ActualizarSesion();
		}

		//lista disponibles
		void LstDisponiblesSelectedIndexChanged(object sender, EventArgs e)
		{
			MostrarPrevia(lstDisponibles);
		}

		//lista seleccionadas
		void LstSeleccionadasSelectedIndexChanged(object sender, EventArgs e)
		{
			MostrarPrevia(lstSeleccionadas);
		}

		//boton >>
		void BtnAgregarClick(object sender, EventArgs e)
		{
			DatosCarta c = lstDisponibles.SelectedItem as DatosCarta;
			if (c == null) return;

			List<DatosCarta> equipo = equipos[cmbJugador.Text];
			if (equipo.Count >= Configuracion.MAX_EQUIPO)
			{
				MessageBox.Show("El equipo ya tiene " + Configuracion.MAX_EQUIPO + " cartas.");
				return;
			}
			if (EstaEnEquipo(equipo, c))
			{
				MessageBox.Show("Esa carta ya está en el equipo.");
				return;
			}

			equipo.Add(c);
			CargarSeleccionadas();
		}

		//boton <<
		void BtnQuitarClick(object sender, EventArgs e)
		{
			DatosCarta c = lstSeleccionadas.SelectedItem as DatosCarta;
			if (c == null) return;

			equipos[cmbJugador.Text].Remove(c);
			CargarSeleccionadas();
		}

		//boton sesion
		void BtnSesionClick(object sender, EventArgs e)
		{
			int n = cmbJugador.SelectedIndex + 1;
			FormLogin login = new FormLogin(n);
			if (login.ShowDialog() == DialogResult.OK)
			{
				perfiles[n] = login.Perfil;
				ActualizarSesion();
			}
			login.Dispose();
		}

		//boton guardar equipo en la BD
		void BtnGuardarClick(object sender, EventArgs e)
		{
			int n = cmbJugador.SelectedIndex + 1;
			if (perfiles[n] == null || perfiles[n].Id == 0)
			{
				MessageBox.Show("Inicia sesión con una cuenta para guardar el equipo.");
				return;
			}

			List<DatosCarta> equipo = equipos[cmbJugador.Text];
			if (equipo.Count != Configuracion.MAX_EQUIPO)
			{
				MessageBox.Show("El equipo debe tener " + Configuracion.MAX_EQUIPO + " cartas.");
				return;
			}

			string error = Almacen.GuardarEquipo(perfiles[n].Id, equipo);
			if (error == "")
			{
				MessageBox.Show("Equipo guardado.");
			}
			else
			{
				MessageBox.Show("No se pudo guardar: " + error);
			}
		}

		//boton cargar equipo de la BD
		void BtnCargarClick(object sender, EventArgs e)
		{
			int n = cmbJugador.SelectedIndex + 1;
			if (perfiles[n] == null || perfiles[n].Id == 0)
			{
				MessageBox.Show("Inicia sesión con una cuenta para cargar el equipo.");
				return;
			}

			List<DatosCarta> guardado = Almacen.CargarEquipo(perfiles[n].Id);
			if (guardado.Count == 0)
			{
				MessageBox.Show("Este jugador todavía no tiene un equipo guardado.");
				return;
			}

			equipos[cmbJugador.Text] = guardado;
			CargarSeleccionadas();
		}

		//boton iniciar
		void BtnIniciarClick(object sender, EventArgs e)
		{
			int modo = cmbModo.SelectedIndex;

			//el jugador 1 siempre debe tener sesion y equipo
			if (perfiles[1] == null)
			{
				MessageBox.Show("El Jugador 1 debe iniciar sesión (o entrar como invitado).");
				return;
			}
			if (equipos["Jugador 1"].Count != Configuracion.MAX_EQUIPO)
			{
				MessageBox.Show("El Jugador 1 debe tener " + Configuracion.MAX_EQUIPO + " cartas.");
				return;
			}

			if (modo == 0)
			{
				IniciarLocal();
			}
			else if (modo == 1)
			{
				IniciarMaquina();
			}
			else
			{
				IniciarRed(modo == 2);
			}
		}

		//modo local: dos jugadores en la misma computadora
		void IniciarLocal()
		{
			if (perfiles[2] == null)
			{
				MessageBox.Show("El Jugador 2 debe iniciar sesión (o entrar como invitado).");
				return;
			}
			if (equipos["Jugador 2"].Count != Configuracion.MAX_EQUIPO)
			{
				MessageBox.Show("El Jugador 2 debe tener " + Configuracion.MAX_EQUIPO + " cartas.");
				return;
			}
			if (perfiles[1].Nombre == perfiles[2].Nombre)
			{
				MessageBox.Show("Los dos jugadores deben ser distintos.");
				return;
			}

			Random r = new Random();
			Jugador a = new Jugador(perfiles[1].Nombre, 1, equipos["Jugador 1"]);
			Jugador b = new Jugador(perfiles[2].Nombre, 2, equipos["Jugador 2"]);
			Partida p = new Partida(a, b, r.Next(1, 100000), r.Next(1, 3), Configuracion.EscenarioAlterno);

			AbrirBatalla(p, FormBatalla.MODO_LOCAL, 0, null, perfiles);
		}

		//modo contra la maquina
		void IniciarMaquina()
		{
			//si el jugador 2 no armo equipo, la maquina elige al azar
			List<DatosCarta> equipoMaquina = equipos["Jugador 2"];
			if (equipoMaquina.Count != Configuracion.MAX_EQUIPO)
			{
				equipoMaquina = new List<DatosCarta>();
				Random azar = new Random();
				while (equipoMaquina.Count < Configuracion.MAX_EQUIPO)
				{
					DatosCarta c = catalogo[azar.Next(catalogo.Count)];
					if (!EstaEnEquipo(equipoMaquina, c))
					{
						equipoMaquina.Add(c);
					}
				}
			}

			Random r = new Random();
			Jugador a = new Jugador(perfiles[1].Nombre, 1, equipos["Jugador 1"]);
			Jugador b = new Jugador("Máquina", 2, equipoMaquina);
			Partida p = new Partida(a, b, r.Next(1, 100000), r.Next(1, 3), Configuracion.EscenarioAlterno);

			PerfilJugador[] soloUno = new PerfilJugador[3];
			soloUno[1] = perfiles[1];
			AbrirBatalla(p, FormBatalla.MODO_MAQUINA, 1, null, soloUno);
		}

		//modo red (servidor o cliente)
		void IniciarRed(bool soyServidor)
		{
			int puerto;
			if (!int.TryParse(txtPuerto.Text, out puerto))
			{
				MessageBox.Show("El puerto no es válido.");
				return;
			}

			//ventana que conecta con el otro jugador
			FormConexion conexion = new FormConexion(soyServidor, txtIp.Text.Trim(), puerto,
				perfiles[1].Nombre, equipos["Jugador 1"], Configuracion.EscenarioAlterno);
			if (conexion.ShowDialog() != DialogResult.OK)
			{
				conexion.Dispose();
				return;
			}

			//datos que llegaron del rival
			Red red = conexion.Conexion;
			string nombreRival = conexion.NombreRival;
			int semilla = conexion.Semilla;
			int inicia = conexion.Inicia;
			bool alterno = conexion.Alterno;

			List<DatosCarta> equipoRival = new List<DatosCarta>();
			foreach (string nombre in conexion.EquipoRival)
			{
				DatosCarta c = Catalogo.BuscarPorNombre(nombre);
				if (c == null)
				{
					MessageBox.Show("El rival usa una carta que no existe aquí: " + nombre);
					red.Cerrar();
					conexion.Dispose();
					return;
				}
				equipoRival.Add(c);
			}
			conexion.Dispose();

			//el servidor es el Jugador 1 y el cliente es el Jugador 2
			Jugador j1;
			Jugador j2;
			int local;
			if (soyServidor)
			{
				local = 1;
				j1 = new Jugador(perfiles[1].Nombre, 1, equipos["Jugador 1"]);
				j2 = new Jugador(nombreRival, 2, equipoRival);
			}
			else
			{
				local = 2;
				j1 = new Jugador(nombreRival, 1, equipoRival);
				j2 = new Jugador(perfiles[1].Nombre, 2, equipos["Jugador 1"]);
			}

			PerfilJugador[] soloLocal = new PerfilJugador[3];
			soloLocal[local] = perfiles[1];

			Partida p = new Partida(j1, j2, semilla, inicia, alterno);
			AbrirBatalla(p, FormBatalla.MODO_RED, local, red, soloLocal);
		}

		//abrir el tablero
		void AbrirBatalla(Partida p, int modo, int local, Red red, PerfilJugador[] pf)
		{
			Hide();
			FormBatalla batalla = new FormBatalla(this, p, modo, local, red, pf);
			batalla.Show();
		}

		//boton volver
		void BtnVolverClick(object sender, EventArgs e)
		{
			Close();
		}

		//al cerrar se muestra el menu
		void FormConfiguracionFormClosed(object sender, FormClosedEventArgs e)
		{
			if (anterior != null) anterior.Show();
		}
	}
}
