﻿/*
 * Archivo del Designer de FormOpciones
 */
namespace ArenaElemental
{
	partial class FormOpciones
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.lblTiempo = new System.Windows.Forms.Label();
			this.cmbTiempo = new System.Windows.Forms.ComboBox();
			this.lblEscenario = new System.Windows.Forms.Label();
			this.cmbEscenario = new System.Windows.Forms.ComboBox();
			this.btnVolver = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.Location = new System.Drawing.Point(20, 10);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Size = new System.Drawing.Size(300, 45);
			this.lblTitulo.TabIndex = 0;
			this.lblTitulo.Text = "Opciones";
			// 
			// lblTiempo
			// 
			this.lblTiempo.Location = new System.Drawing.Point(200, 110);
			this.lblTiempo.Name = "lblTiempo";
			this.lblTiempo.Size = new System.Drawing.Size(220, 30);
			this.lblTiempo.TabIndex = 1;
			this.lblTiempo.Text = "Tiempo por turno";
			// 
			// cmbTiempo
			// 
			this.cmbTiempo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTiempo.Items.AddRange(new object[] {
			"15 segundos",
			"20 segundos",
			"30 segundos"});
			this.cmbTiempo.Location = new System.Drawing.Point(430, 108);
			this.cmbTiempo.Name = "cmbTiempo";
			this.cmbTiempo.Size = new System.Drawing.Size(200, 21);
			this.cmbTiempo.TabIndex = 2;
			// 
			// lblEscenario
			// 
			this.lblEscenario.Location = new System.Drawing.Point(200, 170);
			this.lblEscenario.Name = "lblEscenario";
			this.lblEscenario.Size = new System.Drawing.Size(220, 30);
			this.lblEscenario.TabIndex = 3;
			this.lblEscenario.Text = "Escenarios";
			// 
			// cmbEscenario
			// 
			this.cmbEscenario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbEscenario.Items.AddRange(new object[] {
			"Un escenario fijo",
			"Dos escenarios alternantes"});
			this.cmbEscenario.Location = new System.Drawing.Point(430, 168);
			this.cmbEscenario.Name = "cmbEscenario";
			this.cmbEscenario.Size = new System.Drawing.Size(320, 21);
			this.cmbEscenario.TabIndex = 4;
			// 
			// btnVolver
			// 
			this.btnVolver.Location = new System.Drawing.Point(20, 540);
			this.btnVolver.Name = "btnVolver";
			this.btnVolver.Size = new System.Drawing.Size(130, 40);
			this.btnVolver.TabIndex = 5;
			this.btnVolver.Text = "Volver";
			this.btnVolver.Click += new System.EventHandler(this.BtnVolverClick);
			// 
			// FormOpciones
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.lblTiempo);
			this.Controls.Add(this.cmbTiempo);
			this.Controls.Add(this.lblEscenario);
			this.Controls.Add(this.cmbEscenario);
			this.Controls.Add(this.btnVolver);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FormOpciones";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Opciones";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormOpcionesFormClosed);
			this.ResumeLayout(false);

		}
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Label lblTiempo;
		private System.Windows.Forms.ComboBox cmbTiempo;
		private System.Windows.Forms.Label lblEscenario;
		private System.Windows.Forms.ComboBox cmbEscenario;
		private System.Windows.Forms.Button btnVolver;
	}
}
