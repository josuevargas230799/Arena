﻿/*
 * Archivo del Designer de FormMenuPrincipal
 */
namespace ArenaElemental
{
	partial class FormMenuPrincipal
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.btnJugar = new System.Windows.Forms.Button();
			this.btnCartas = new System.Windows.Forms.Button();
			this.btnReglas = new System.Windows.Forms.Button();
			this.btnRanking = new System.Windows.Forms.Button();
			this.btnOpciones = new System.Windows.Forms.Button();
			this.btnSalir = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.AutoSize = false;
			this.lblTitulo.Location = new System.Drawing.Point(0, 20);
			this.lblTitulo.Size = new System.Drawing.Size(1000, 60);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Text = "ARENA ELEMENTAL";
			this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnJugar
			// 
			this.btnJugar.Location = new System.Drawing.Point(420, 235);
			this.btnJugar.Size = new System.Drawing.Size(160, 45);
			this.btnJugar.Name = "btnJugar";
			this.btnJugar.Text = "Jugar";
			this.btnJugar.Click += new System.EventHandler(this.BtnJugarClick);
			// 
			// btnCartas
			// 
			this.btnCartas.Location = new System.Drawing.Point(420, 287);
			this.btnCartas.Size = new System.Drawing.Size(160, 45);
			this.btnCartas.Name = "btnCartas";
			this.btnCartas.Text = "Cartas";
			this.btnCartas.Click += new System.EventHandler(this.BtnCartasClick);
			// 
			// btnReglas
			// 
			this.btnReglas.Location = new System.Drawing.Point(420, 339);
			this.btnReglas.Size = new System.Drawing.Size(160, 45);
			this.btnReglas.Name = "btnReglas";
			this.btnReglas.Text = "Reglas";
			this.btnReglas.Click += new System.EventHandler(this.BtnReglasClick);
			// 
			// btnRanking
			// 
			this.btnRanking.Location = new System.Drawing.Point(420, 391);
			this.btnRanking.Size = new System.Drawing.Size(160, 45);
			this.btnRanking.Name = "btnRanking";
			this.btnRanking.Text = "Ranking";
			this.btnRanking.Click += new System.EventHandler(this.BtnRankingClick);
			// 
			// btnOpciones
			// 
			this.btnOpciones.Location = new System.Drawing.Point(420, 443);
			this.btnOpciones.Size = new System.Drawing.Size(160, 45);
			this.btnOpciones.Name = "btnOpciones";
			this.btnOpciones.Text = "Opciones";
			this.btnOpciones.Click += new System.EventHandler(this.BtnOpcionesClick);
			// 
			// btnSalir
			// 
			this.btnSalir.Location = new System.Drawing.Point(420, 495);
			this.btnSalir.Size = new System.Drawing.Size(160, 45);
			this.btnSalir.Name = "btnSalir";
			this.btnSalir.Text = "Salir";
			this.btnSalir.Click += new System.EventHandler(this.BtnSalirClick);
			// 
			// FormMenuPrincipal
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.btnJugar);
			this.Controls.Add(this.btnCartas);
			this.Controls.Add(this.btnReglas);
			this.Controls.Add(this.btnRanking);
			this.Controls.Add(this.btnOpciones);
			this.Controls.Add(this.btnSalir);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FormMenuPrincipal";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FormMenuPrincipal";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Button btnJugar;
		private System.Windows.Forms.Button btnCartas;
		private System.Windows.Forms.Button btnReglas;
		private System.Windows.Forms.Button btnRanking;
		private System.Windows.Forms.Button btnOpciones;
		private System.Windows.Forms.Button btnSalir;
	}
}
