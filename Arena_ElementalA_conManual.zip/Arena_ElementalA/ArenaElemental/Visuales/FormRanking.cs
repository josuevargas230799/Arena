﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ArenaElemental
{
	public partial class FormRanking : Form
	{
		Form anterior;

		public FormRanking()
		{
			InitializeComponent();
			Estilo.Aplicar(this, "fondo_juego.png");
			CargarRanking();
		}

		public FormRanking(Form menu) : this()
		{
			anterior = menu;
		}

		//ranking
		void CargarRanking()
		{
			List<PerfilJugador> lista = Almacen.ObtenerRanking();

			int posicion = 1;
			foreach (PerfilJugador p in lista)
			{
				ListViewItem item = new ListViewItem(posicion.ToString());
				item.SubItems.Add(p.Nombre);
				item.SubItems.Add(p.Partidas.ToString());
				item.SubItems.Add(p.Victorias.ToString());
				item.SubItems.Add(p.Derrotas.ToString());
				item.SubItems.Add(p.PorcentajeExito.ToString("0.0") + " %");
				lvRanking.Items.Add(item);
				posicion++;
			}

			if (Almacen.UltimoError != "")
			{
				lblMensaje.Text = "No se pudo leer el archivo de jugadores.";
			}
			else if (lista.Count == 0)
			{
				lblMensaje.Text = "Todavía no hay jugadores registrados.";
			}
		}

		//boton volver
		void BtnVolverClick(object sender, EventArgs e)
		{
			Close();
		}

		//al cerrar se muestra el menu
		void FormRankingFormClosed(object sender, FormClosedEventArgs e)
		{
			if (anterior != null) anterior.Show();
		}
	}
}
